#!/bin/bash
# Tek seferlik kurulum: sitenin kendi içinden güncellenebilmesini sağlar ve bu paketi yükler.
# root olarak çalıştırılır.
set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
D=/var/lib/evrak/guncelleme
mkdir -p "$D"
chown evrak:evrak "$D"

cat > /usr/local/bin/evrak-guncelle.sh <<'EOS'
#!/bin/bash
# Site yönetiminden yüklenen güncelleme paketini denetler, uygular, sorun çıkarsa geri alır.
OPT="${EVRAK_OPT:-/opt/evrak}"
D="${EVRAK_UPD:-/var/lib/evrak/guncelleme}"
RESTART="${EVRAK_RESTART:-systemctl restart evrak}"
CHECK="${EVRAK_CHECK:-python3 -c \"import urllib.request;urllib.request.urlopen('http://127.0.0.1:8080/',timeout=5)\"}"
rm -f "$D/hazir"
[ -f "$D/paket.tgz" ] || exit 0
sonuc() { echo "$1" > "$D/sonuc"; chmod 644 "$D/sonuc"; rm -f "$D/paket.tgz"; }
if tar tzf "$D/paket.tgz" | grep -Eq '(^/|\.\.)'; then sonuc "HATA: paket yolu gecersiz"; exit 0; fi
T="$(mktemp -d)"
if ! tar xzf "$D/paket.tgz" -C "$T" --no-same-owner --no-same-permissions; then sonuc "HATA: paket acilamadi"; rm -rf "$T"; exit 0; fi
if [ ! -f "$T/evrak-bulut/server.py" ] || [ ! -f "$T/evrak-bulut/static/index.html" ]; then sonuc "HATA: paket eksik"; rm -rf "$T"; exit 0; fi
if ! python3 -m py_compile "$T/evrak-bulut/server.py"; then sonuc "HATA: server.py gecersiz"; rm -rf "$T"; exit 0; fi
rm -rf "$OPT.onceki"; mkdir -p "$OPT.onceki"
cp -r "$OPT/server.py" "$OPT/qr.py" "$OPT/static" "$OPT.onceki/"
rm -rf "$OPT/static"
cp -r "$T/evrak-bulut/server.py" "$T/evrak-bulut/qr.py" "$T/evrak-bulut/static" "$OPT/"
chown -R root:root "$OPT" 2>/dev/null
eval "$RESTART"
sleep 5
if eval "$CHECK" >/dev/null 2>&1; then
  sonuc "TAMAM $(date '+%d.%m.%Y %H:%M')"
else
  rm -rf "$OPT/static"
  cp -r "$OPT.onceki/server.py" "$OPT.onceki/qr.py" "$OPT.onceki/static" "$OPT/"
  eval "$RESTART"
  sonuc "GERI ALINDI: yeni surum acilmadi, onceki surum yuklendi"
fi
rm -rf "$T"
EOS
chmod 755 /usr/local/bin/evrak-guncelle.sh

cat > /etc/systemd/system/evrak-guncelle.service <<'EOS'
[Unit]
Description=Evrak sistemi guncelleme uygulayici
[Service]
Type=oneshot
ExecStart=/usr/local/bin/evrak-guncelle.sh
EOS
cat > /etc/systemd/system/evrak-guncelle.path <<'EOS'
[Unit]
Description=Evrak guncelleme paketi bekler
[Path]
PathExists=/var/lib/evrak/guncelleme/hazir
Unit=evrak-guncelle.service
[Install]
WantedBy=multi-user.target
EOS
systemctl daemon-reload
systemctl enable --now evrak-guncelle.path
touch "$D/kurulu"
chown evrak:evrak "$D/kurulu"

# Bu paketi de yükle
rm -rf /opt/evrak/static
cp -r "$SRC/server.py" "$SRC/qr.py" "$SRC/static" /opt/evrak/
chown -R root:root /opt/evrak
systemctl restart evrak
echo GUNCELLENDI
