(function () {
"use strict";
/* İmza yardımcısı için antetli belge sayfası (tek kullanımlık imza bileti ile açılır).
   Yazı düzeni app.js içindeki letter() ile aynı tutulmalı. */
function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
function esBlok(e, url) {
  if (!e.vcode) return "";
  return '<div class="es"><img src="/qr/' + encodeURIComponent(e.vcode) + '.svg" alt="Doğrulama karekodu"><div>' +
    "<b>Bu belge, 5070 sayılı Elektronik İmza Kanunu hükümlerine göre güvenli elektronik imza ile imzalanmıştır.</b>" +
    "<span>Doğrulama kodu: " + esc(e.vcode) + "</span><span>Belgeyi doğrulamak için karekodu okutun veya şu adresi açın: " + esc(url) + "</span></div></div>";
}
function fitPaper(p) {
  /* Yazıyı A4'e sığdır: 12 punto'dan başlar, en fazla 10 punto'ya kadar küçülür; yine sığmazsa 2. sayfaya geçer. */
  if (!p) return;
  p.classList.remove("multi"); p.classList.add("fitm");
  var fs = 12; p.style.setProperty("--fs", fs + "pt");
  while (p.scrollHeight > p.clientHeight + 1 && fs > 10) { fs -= 0.25; p.style.setProperty("--fs", fs + "pt"); }
  var over = p.scrollHeight > p.clientHeight + 1;
  p.classList.remove("fitm");
  if (over) p.classList.add("multi");
}
function letter(e, url) {
  var dil = e.kind === "Dilekçe";
  var parts = [e.intro, e.dev, e.res].filter(Boolean).join("\n\n").replace(/\*\*/g, "").split(/\n\s*\n/).filter(function (p) { return p.trim(); }).map(function (p) { p = p.trim(); return "<p" + (/\n/.test(p) ? ' class="ls"' : "") + ">" + esc(p) + "</p>"; }).join("");
  var last = e.signers.length ? e.signers[e.signers.length - 1] : null;
  var sig = "\n\n\n" + (last ? last.name + (last.title ? "\n" + last.title : "") : "");
  return '<div class="paper">' +
    '<div class="lh"><img src="/logo.png" alt=""><div class="lt"><b>ASLANBAŞ YAPI</b><em>ENERJİ GIDA TARIM HAYVANCILIK ANONİM ŞİRKETİ</em><span>Ağrı Vergi Dairesi · VKN: 0890525025</span></div></div>' +
    '<div class="meta"><div class="sk">' + (dil ? "" : "<span>Sayı</span><span>: " + esc(e.no) + "</span>") + "<span>Konu</span><span>: " + esc(e.subj) + "</span></div><div class=\"dt\">" + esc(e.date) + "</div></div>" +
    '<div class="pto">' + esc(e.party.split(";").map(function (x) { return x.trim(); }).filter(Boolean).join("\n").toLocaleUpperCase("tr-TR")) + "" + "</div>" +
    '<div class="body">' + parts + '</div><div class="sig">' + esc(sig) + "</div>" +
    (e.ek ? '<div class="sub">Ek: ' + esc(e.ek) + "</div>" : "") +
    esBlok(e, url) + '<div class="ft">Sıtkıye Mahallesi Yaşar Kemal Caddesi No:27/17 Merkez / AĞRI<br>Tel: 0 532 704 50 30 · E-posta: aslanbasyapi@gmail.com · Web: www.aslanbasyapi.com<br>KEP: aslanbas.hs06.kep.tr · UETS: 25949-01947-94719 · Mersis No: 0089052502500017</div></div>';
}
var t = new URLSearchParams(location.search).get("t") || "";
/* Eşzamanlı istek: sayfanın "load" olayı, belge ve görseller yüklenene kadar beklesin (PDF'e çevirme için). */
try {
  var xr = new XMLHttpRequest();
  xr.open("GET", "/api/helper/" + encodeURIComponent(t) + "/belge", false);
  xr.send();
  var d = JSON.parse(xr.responseText);
  if (xr.status < 200 || xr.status >= 300) throw new Error(d.hata || "Hata");
  document.getElementById("printarea").innerHTML = letter(d.evrak, d.evrak.dogrula_url);
  fitPaper(document.querySelector(".paper"));
  document.title = d.evrak.no;
  document.body.setAttribute("data-hazir", "1");
} catch (x) {
  document.getElementById("printarea").textContent = x.message;
  document.body.setAttribute("data-hata", "1");
}
})();
