(function () {
"use strict";
var app = document.getElementById("app"), me = null;
var PL = {
  gelen_gor: "Gelen evrakı görme", gelen_kaydet: "Gelen evrak kaydetme", giden_hazirla: "Giden evrak hazırlama",
  havale: "Havale etme", imzala: "Evrak imzalama (e-imza kartı olanlar)", arsiv: "Tüm giden evrakları görme (arşiv)",
  yonet: "Personel ve yetki yönetimi"
};
var PORDER = ["gelen_gor", "gelen_kaydet", "giden_hazirla", "havale", "imzala", "arsiv", "yonet"];
var ST = { acik: "Açık", kapandi: "Kapandı", taslak: "Taslak", imzada: "İmzada", aktif: "Aktif" };

function $(s, r) { return (r || document).querySelector(s); }
function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
function fmt(ts) { return ts ? new Date(ts * 1000).toLocaleString("tr-TR") : ""; }
function has(p) { return me.perms.indexOf(p) > -1 || (p !== "imzala" && me.perms.indexOf("yonet") > -1); }
function api(m, p, b) {
  return fetch("/api/" + p, {
    method: m, credentials: "same-origin",
    headers: { "Content-Type": "application/json", "X-Requested-With": "evrak" },
    body: b ? JSON.stringify(b) : undefined
  }).then(function (r) {
    return r.json().catch(function () { return {}; }).then(function (d) {
      if (!r.ok) {
        if (r.status === 401 && me) { me = null; route(); }
        throw new Error(d.hata || "İşlem başarısız.");
      }
      return d;
    });
  });
}
function toB64(file) {
  return new Promise(function (ok, no) {
    var r = new FileReader();
    r.onload = function () { ok({ name: file.name, data: String(r.result).split(",")[1] }); };
    r.onerror = no; r.readAsDataURL(file);
  });
}
/* Yapay zekâya gidecek dosya: fotoğraflar küçültülür (telefon fotoğrafları büyük olur), PDF olduğu gibi gider */
function aiDosya(file) {
  if (!/^image\//.test(file.type)) return toB64(file);
  return new Promise(function (ok, no) {
    var url = URL.createObjectURL(file), im = new Image();
    im.onload = function () {
      var k = Math.min(1, 1800 / Math.max(im.width, im.height)), cv = document.createElement("canvas");
      cv.width = Math.round(im.width * k); cv.height = Math.round(im.height * k);
      cv.getContext("2d").drawImage(im, 0, 0, cv.width, cv.height);
      URL.revokeObjectURL(url);
      ok({ name: file.name, data: cv.toDataURL("image/jpeg", 0.85).split(",")[1] });
    };
    im.onerror = function () { URL.revokeObjectURL(url); toB64(file).then(ok, no); };
    im.src = url;
  });
}
function flash(msg, kind) {
  var f = $("#flash"); if (!f) return;
  f.innerHTML = msg ? '<div class="msg ' + (kind || "") + '" role="status">' + esc(msg) + "</div>" : "";
  if (msg) window.scrollTo(0, 0);
}
function fail(e) { flash(e.message || "İşlem başarısız.", "bad"); }

function shell(active, inner) {
  var sw = me.sign_wait || [];
  var tabs = [["ana", "Ana sayfa"], ["gelen", "Gelen"], ["giden", "Giden" + (sw.length ? " (" + sw.length + " imza bekliyor)" : "")], ["dosyalar", "Dosyalar"], ["kurumlar", "Kurumlar"]];
  if (has("yonet")) tabs.push(["personel", "Personel" + (me.requests ? " (" + me.requests + " talep)" : "")], ["kayit", "Kayıt defteri"], ["sistem", "Sistem"]);
  tabs.push(["sifre", "Şifre ve güvenlik"]);
  app.innerHTML = '<div class="wrap"><div class="top"><img src="/logo.png" alt=""><h1>Aslanbaş Evrak Takip<small>' +
    esc(me.name) + (me.title ? " · " + esc(me.title) : "") + '</small></h1><span class="sp"></span><form class="gs" id="gsf" role="search"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg><input id="gq" type="search" placeholder="Evrak ara: sayı, kurum, konu…" autocomplete="off" aria-label="Evrak ara"><div class="gres" id="gres" hidden></div></form><button class="btn ghost" id="out">Çıkış</button></div><nav>' +
    tabs.map(function (t) { return '<button data-t="' + t[0] + '"' + (t[0] === active ? ' aria-current="true"' : "") + ">" + t[1] + "</button>"; }).join("") +
    "</nav>" + ((me.approve_wait || []).length ? '<div class="msg bad"><b>Onayınızı bekleyen ' + me.approve_wait.length + ' evrak var.</b> <a href="#/' + (me.approve_wait.length === 1 ? "evrak/" + me.approve_wait[0] : "giden") + '">' + (me.approve_wait.length === 1 ? "Evrakı aç ve onayla" : "Giden evraklara git") + "</a></div>" : "") +
    (sw.length ? '<div class="msg bad"><b>İmzanızı bekleyen ' + sw.length + ' evrak var.</b> <a href="#/' + (sw.length === 1 ? "evrak/" + sw[0] : "giden") + '">' + (sw.length === 1 ? "Evrakı aç ve imzala" : "Giden evraklara git") + "</a></div>" : "") +
    '<div id="flash"></div><div id="view">' + inner + "</div></div>";
  Array.prototype.forEach.call(app.querySelectorAll("nav button"), function (b) {
    b.onclick = function () { location.hash = "#/" + b.getAttribute("data-t"); };
  });
  initSearch();
  $("#out").onclick = function () { api("POST", "logout").then(function () { me = null; location.hash = "#/giris"; route(); }); };
}

/* ---------- giriş / davet ---------- */
function loginView() {
  app.innerHTML = '<div class="wrap"><form class="card login" id="lf"><img src="/logo.png" alt=""><h1>Aslanbaş Evrak Takip</h1><div id="flash"></div>' +
    '<label for="em">E-posta</label><input id="em" type="email" autocomplete="username" required>' +
    '<label for="pw">Şifre</label><input id="pw" type="password" autocomplete="current-password" required>' +
    '<div class="acts"><button class="btn" type="submit">Giriş yap</button></div>' +
    '<p class="sub">Şifrenizi unuttuysanız yöneticiden yeni bağlantı isteyin.</p>' +
    '<div class="acts"><a href="#/talep">Hesabınız yok mu? Hesap talep edin</a></div></form></div>';
  $("#lf").onsubmit = function (e) {
    e.preventDefault();
    var body = { email: $("#em").value, password: $("#pw").value };
    if ($("#cd")) { body.code = $("#cd").value; body.trust = $("#tr").checked; }
    api("POST", "login", body).then(function (d) {
      if (d.need_2fa) {
        $("#em").readOnly = true; $("#pw").readOnly = true;
        var lab = d.via === "mail" ? "E-postanıza (" + esc(d.to) + ") gönderilen 6 haneli kodu yazın" : "Telefondaki uygulamanın 6 haneli kodunu yazın";
        $("#lf .acts").insertAdjacentHTML("beforebegin", '<label for="cd">' + lab + '</label><input id="cd" inputmode="numeric" autocomplete="one-time-code" maxlength="8" required>' +
          '<label class="chk"><input type="checkbox" id="tr"> Bu bilgisayara 30 gün güven (tekrar kod sormasın)</label>' +
          (d.via === "mail" ? '<p class="sub">Kod gelmediyse Spam klasörüne bakın. <a href="#" id="rs">Kodu tekrar gönder</a></p>' : ""));
        if ($("#rs")) $("#rs").onclick = function (ev) {
          ev.preventDefault();
          api("POST", "login", { email: $("#em").value, password: $("#pw").value }).then(function () { flash("Yeni kod gönderildi.", "ok"); }).catch(fail);
        };
        $("#cd").focus(); return;
      }
      me = d.user; location.hash = me.must_2fa ? "#/sifre" : "#/ana"; route();
    }).catch(fail);
  };
}
function requestView() {
  app.innerHTML = '<div class="wrap"><form class="card login" id="rf"><img src="/logo.png" alt=""><h1>Hesap talebi</h1><div id="flash"></div>' +
    '<p class="sub">Bilgilerinizi ve kendi belirlediğiniz şifreyi yazın. Yönetici onaylayınca aynı şifreyle giriş yaparsınız.</p>' +
    '<label for="nm">Ad soyad</label><input id="nm" autocomplete="name" required>' +
    '<label for="tt">Görev</label><input id="tt">' +
    '<label for="em">E-posta</label><input id="em" type="email" autocomplete="username" required>' +
    '<label for="p1">Şifre (en az 10 karakter)</label><input id="p1" type="password" autocomplete="new-password" minlength="10" required>' +
    '<label for="p2">Şifre (tekrar)</label><input id="p2" type="password" autocomplete="new-password" minlength="10" required>' +
    '<div class="acts"><button class="btn" type="submit">Talebi gönder</button><a href="#/giris">Girişe dön</a></div></form></div>';
  $("#rf").onsubmit = function (e) {
    e.preventDefault();
    if ($("#p1").value !== $("#p2").value) return flash("İki şifre aynı değil.", "bad");
    api("POST", "request", { name: $("#nm").value, title: $("#tt").value, email: $("#em").value, password: $("#p1").value }).then(function () {
      app.innerHTML = '<div class="wrap"><div class="card login"><img src="/logo.png" alt=""><div class="msg ok">Talebiniz alındı. Yönetici onaylayınca e-posta adresiniz ve belirlediğiniz şifreyle giriş yapabilirsiniz.</div><div class="acts"><a href="#/giris">Girişe dön</a></div></div></div>';
    }).catch(fail);
  };
}
function inviteView(token) {
  api("GET", "invite/" + encodeURIComponent(token)).then(function (d) {
    app.innerHTML = '<div class="wrap"><form class="card login" id="inf"><img src="/logo.png" alt=""><h1>Şifre belirleyin</h1><div id="flash"></div>' +
      '<p>' + esc(d.name) + " (" + esc(d.email) + ')</p><label for="p1">Yeni şifre (en az 10 karakter)</label><input id="p1" type="password" autocomplete="new-password" minlength="10" required>' +
      '<label for="p2">Şifre tekrar</label><input id="p2" type="password" autocomplete="new-password" minlength="10" required>' +
      '<div class="acts"><button class="btn" type="submit">Kaydet ve gir</button></div></form></div>';
    $("#inf").onsubmit = function (e) {
      e.preventDefault();
      if ($("#p1").value !== $("#p2").value) return flash("Şifreler aynı değil.", "bad");
      api("POST", "invite/accept", { token: token, password: $("#p1").value }).then(function (r) {
        me = r.user; location.hash = "#/ana"; route();
      }).catch(fail);
    };
  }).catch(function (e) {
    app.innerHTML = '<div class="wrap"><div class="card login"><div class="msg bad">' + esc(e.message) + "</div></div></div>";
  });
}

/* ---------- evrak listeleri ---------- */
function itemHTML(e) {
  var cls = e.type === "out" ? " out" : "";
  var ok = e.status === "aktif" || e.status === "kapandi";
  return '<div class="card item' + cls + '" tabindex="0" role="link" data-id="' + e.id + '"><div class="row"><span class="no">' + esc(e.no) +
    '</span><span class="tag ' + (ok ? "ok" : "") + '">' + ST[e.status] + "</span></div><div>" + esc(e.subj) + '</div><div class="sub">' +
    (e.type === "in" ? "Gönderen: " : "Alıcı: ") + esc(e.party) + " · " + esc(e.date) + "</div>" +
    (e.ref_no || e.ref_date ? '<div class="sub">Evrak sayısı / tarihi: ' + esc(e.ref_no) + " · " + esc(e.ref_date) + "</div>" : "") +
    (e.to_user_name ? '<div class="sub">Havale: ' + esc(e.to_user_name) + "</div>" : "") + dueTag(e) + "</div>";
}
function dueTag(e) {
  if (e.due_days === null || e.due_days === undefined) return "";
  var k = e.due_days, t = k < 0 ? "Süresi " + (-k) + " gün geçti" : k === 0 ? "Son gün BUGÜN" : k + " gün kaldı";
  return '<div class="due' + (k < 0 ? " late" : k <= 3 ? " soon" : "") + '">Cevap son tarihi: ' + esc(e.due.split("-").reverse().join(".")) + " · " + t + "</div>";
}
function rowHTML(e) {
  var ok = e.status === "aktif" || e.status === "kapandi";
  return '<div class="lrow ' + e.type + '" tabindex="0" role="link" data-id="' + e.id + '">' +
    '<div class="lno">' + esc(e.no) + '</div>' +
    '<div class="lmain"><b>' + esc(e.subj) + '</b><span>' + (e.type === "in" ? "Gönderen: " : "Alıcı: ") + esc(e.party) +
    (e.to_user_name ? " · Havale: " + esc(e.to_user_name) : "") + '</span>' + dueTag(e) + '</div>' +
    '<div class="ldate">' + esc(e.date) + '</div>' +
    '<div class="lst"><span class="tag ' + (ok ? "ok" : "") + '">' + ST[e.status] + "</span></div></div>";
}
function listView(type, autoNew) {
  var canNew = type === "in" ? has("gelen_kaydet") : has("giden_hazirla");
  var S = { page: 1, durum: "", yil: "", kurum: "", sirala: "yeni", size: 25 };
  shell(type === "in" ? "gelen" : "giden",
    '<div class="bar"><input id="q" type="search" placeholder="Ara: no, kurum, konu, yazı metni, ek adı, imzalayan, tarih">' +
    (canNew ? '<button class="btn" id="new">Yeni</button>' : "") + '<button class="btn ghost" id="xl">Excel\'e aktar</button></div>' +
    '<div class="filters"><select id="fd" aria-label="Durum"></select><select id="fy" aria-label="Yıl"></select>' +
    '<input id="fk" type="search" placeholder="Kurum filtrele" aria-label="Kurum">' +
    '<select id="fs" aria-label="Sıralama"><option value="yeni">En yeni üstte</option><option value="eski">En eski üstte</option><option value="konu">Konuya göre (A-Z)</option><option value="kurum">Kuruma göre (A-Z)</option></select>' +
    '<button class="btn ghost" id="fc" type="button">Süzgeçleri temizle</button></div>' +
    '<div id="form"></div><div class="lhead"><span>No</span><span>Konu / Kurum</span><span>Tarih</span><span>Durum</span></div><div id="list" class="llist"><div class="empty">Yükleniyor…</div></div><div id="pager" class="pager"></div>');
  function pager(d) {
    var el = $("#pager"); if (!d.total) { el.innerHTML = ""; return; }
    var a = (d.page - 1) * d.size + 1, b = Math.min(d.page * d.size, d.total), h = '<span class="sub">' + a + "–" + b + " / " + d.total + " evrak</span><span class=\"pg\">";
    h += '<button class="btn ghost" data-p="' + (d.page - 1) + '"' + (d.page <= 1 ? " disabled" : "") + ">‹ Önceki</button>";
    var from = Math.max(1, d.page - 2), to = Math.min(d.pages, d.page + 2);
    if (from > 1) h += '<button class="btn ghost pn" data-p="1">1</button>' + (from > 2 ? "<span>…</span>" : "");
    for (var p = from; p <= to; p++) h += '<button class="btn ghost pn' + (p === d.page ? " cur" : "") + '" data-p="' + p + '">' + p + "</button>";
    if (to < d.pages) h += (to < d.pages - 1 ? "<span>…</span>" : "") + '<button class="btn ghost pn" data-p="' + d.pages + '">' + d.pages + "</button>";
    h += '<button class="btn ghost" data-p="' + (d.page + 1) + '"' + (d.page >= d.pages ? " disabled" : "") + ">Sonraki ›</button></span>" +
      '<select id="ps" aria-label="Sayfa başına">' + [25, 50, 100].map(function (n) { return '<option value="' + n + '"' + (n === d.size ? " selected" : "") + ">" + n + " / sayfa</option>"; }).join("") + "</select>";
    el.innerHTML = h;
    Array.prototype.forEach.call(el.querySelectorAll("button[data-p]"), function (bt) { bt.onclick = function () { S.page = Number(bt.getAttribute("data-p")); load(); window.scrollTo(0, 0); }; });
    $("#ps").onchange = function () { S.size = Number(this.value); S.page = 1; load(); };
  }
  function filt(d) {
    var fd = $("#fd"), fy = $("#fy");
    if (fd.getAttribute("data-set") !== "1") {
      var tot = 0, k; for (k in d.sayac) tot += d.sayac[k];
      fd.innerHTML = '<option value="">Tüm durumlar (' + tot + ")</option>" + Object.keys(d.sayac).map(function (k) { return '<option value="' + k + '">' + esc(ST[k] || k) + " (" + d.sayac[k] + ")</option>"; }).join("");
      fy.innerHTML = '<option value="">Tüm yıllar</option>' + d.yillar.map(function (y) { return '<option value="' + y + '">' + y + "</option>"; }).join("");
      fd.setAttribute("data-set", "1"); fd.value = S.durum; fy.value = S.yil;
    }
  }
  function load() {
    var qs = "evrak?type=" + type + "&q=" + encodeURIComponent($("#q").value) + "&page=" + S.page + "&size=" + S.size + "&sirala=" + S.sirala +
      "&durum=" + encodeURIComponent(S.durum) + "&yil=" + encodeURIComponent(S.yil) + "&kurum=" + encodeURIComponent(S.kurum);
    api("GET", qs).then(function (d) {
      filt(d);
      $("#list").innerHTML = d.evrak.map(rowHTML).join("") || '<div class="empty">Kayıt yok.</div>';
      Array.prototype.forEach.call(document.querySelectorAll(".lrow"), function (el) {
        function go() { location.hash = "#/evrak/" + el.getAttribute("data-id"); }
        el.onclick = go; el.onkeydown = function (ev) { if (ev.key === "Enter") go(); };
      });
      pager(d);
    }).catch(fail);
  }
  function again() { S.page = 1; load(); }
  $("#fd").onchange = function () { S.durum = this.value; again(); };
  $("#fy").onchange = function () { S.yil = this.value; again(); };
  $("#fs").onchange = function () { S.sirala = this.value; again(); };
  var tk; $("#fk").oninput = function () { var v = this.value; clearTimeout(tk); tk = setTimeout(function () { S.kurum = v; again(); }, 250); };
  $("#fc").onclick = function () { S.durum = ""; S.yil = ""; S.kurum = ""; S.sirala = "yeni"; $("#q").value = ""; $("#fk").value = ""; $("#fs").value = "yeni"; $("#fd").value = ""; $("#fy").value = ""; again(); };
  $("#xl").onclick = function () {
    fetch("/api/rapor?type=" + type, { credentials: "same-origin", headers: { "X-Requested-With": "evrak" } }).then(function (r) {
      if (!r.ok) throw new Error("Rapor alınamadı."); return r.blob();
    }).then(function (b) {
      var l = document.createElement("a"); l.href = URL.createObjectURL(b); l.download = (type === "in" ? "gelen" : "giden") + ".xlsx";
      document.body.appendChild(l); l.click(); l.remove();
    }).catch(fail);
  };
  var t; $("#q").oninput = function () { clearTimeout(t); t = setTimeout(again, 250); };
  load();
  if (canNew) {
    $("#new").onclick = function () { type === "in" ? formIn(load) : formOut(null, load); };
    if (autoNew) $("#new").click();
  }
}
function usersLite() { return api("GET", "users/lite").then(function (d) { return d.users; }); }

function kurumList() { return api("GET", "kurumlar").then(function (d) { return d.kurumlar; }).catch(function () { return []; }); }
function kurumOpts(ks) { return '<datalist id="kl">' + ks.map(function (k) { return '<option value="' + esc(k.name) + '">'; }).join("") + "</datalist>"; }
document.addEventListener("click", function (ev) {
  if (!ev.target || ev.target.id !== "tbh") return;
  var tb = document.getElementById("tb").value, g = Number(document.getElementById("tg").value), m = document.getElementById("tbm");
  if (!tb || !g) { m.textContent = "Tebliğ tarihini ve süreyi (gün) girin."; return; }
  var d = new Date(tb + "T12:00:00");
  if (document.getElementById("te").checked) d.setDate(d.getDate() + 5);
  d.setDate(d.getDate() + g);
  while (d.getDay() === 0 || d.getDay() === 6) d.setDate(d.getDate() + 1);
  var iso = d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2);
  document.getElementById("du").value = iso;
  m.textContent = "Son tarih: " + iso.split("-").reverse().join(".") + " olarak yazıldı.";
});
function formIn(done) {
  var pre = Promise.all([has("havale") ? usersLite() : Promise.resolve([]), kurumList()]);
  pre.then(function (rs) {
    var us = rs[0], ks = rs[1];
    $("#form").innerHTML = '<form class="card" id="nf"><label for="file">Evrak dosyası (PDF veya fotoğraf, isteğe bağlı)</label><input id="file" type="file" accept="application/pdf,image/*">' +
      (me.ai && has("gelen_kaydet") ? '<div class="acts"><button class="btn ghost" type="button" id="aio">Yapay zekâ ile oku ve doldur</button></div><div class="sub" id="aim">Dosyayı seçtikten sonra bu düğme formu sizin için doldurur. Evrakın içeriği yapay zekâ hizmetine gönderilir; gizli evraklarda kullanmayın. Doldurulanları kontrol edin.</div>' : "") +
      '<label for="party">Gönderen kurum / kişi</label><input id="party" required list="kl" autocomplete="off">' + kurumOpts(ks) +
      '<label for="subj">Konu</label><input id="subj" required>' +
      '<label for="rn">Evrakın sayısı (karşı kurumun)</label><input id="rn">' +
      '<label for="rd">Evrakın tarihi</label><input id="rd">' +
      (us.length ? '<label for="tu">Havale edilen kişi</label><select id="tu"><option value="">Havale yok</option>' + us.map(function (u) { return '<option value="' + u.id + '">' + esc(u.name) + (u.title ? " · " + esc(u.title) : "") + "</option>"; }).join("") + "</select>" : "") +
      (us.length ? '<label for="hn">Havale notu (havale edilen kişiye gider)</label><input id="hn" maxlength="500">' : "") +
      '<label for="du">Cevap için son tarih (varsa)</label><input id="du" type="date">' +
      '<details class="sub"><summary>Tebliğ tarihinden son tarih hesapla</summary>' +
      '<label for="tb">Tebliğ tarihi</label><input id="tb" type="date">' +
      '<label for="tg">Süre (gün)</label><input id="tg" type="number" min="1" max="365" placeholder="Örn. 7, 15, 30">' +
      '<label class="perms"><span><input type="checkbox" id="te"> Elektronik tebligat (gönderimden 5 gün sonra tebliğ sayılır)</span></label>' +
      '<div class="acts"><button class="btn ghost" type="button" id="tbh">Son tarihi hesapla</button></div>' +
      '<p class="sub" id="tbm">Hafta sonuna denk gelirse sonraki iş gününe alınır. Resmî tatilleri hesaba katmaz, önemli sürelerde kontrol edin.</p></details>' +
      '<label for="nt">Not</label><textarea id="nt" rows="2"></textarea>' +
      '<div class="acts"><button class="btn" type="submit">Kaydet</button><button class="btn ghost" type="button" id="cn">Vazgeç</button></div></form>';    $("#cn").onclick = function () { $("#form").innerHTML = ""; };
    if ($("#aio")) $("#aio").onclick = function () {
      var b = this, f = $("#file").files[0];
      if (!f) return flash("Önce evrak dosyasını (PDF ya da fotoğraf) seçin.", "bad");
      b.disabled = true; b.textContent = "Okunuyor… (yarım dakika sürebilir)";
      aiDosya(f).then(function (file) { return api("POST", "ai/oku", { file: file }); }).then(function (r) {
        if (r.gonderen) $("#party").value = r.gonderen;
        if (r.konu) $("#subj").value = r.konu;
        if (r.evrak_sayisi) $("#rn").value = r.evrak_sayisi;
        if (r.evrak_tarihi) $("#rd").value = r.evrak_tarihi;
        if (r.son_tarih) $("#du").value = r.son_tarih;
        if (r.havale_id && $("#tu")) $("#tu").value = r.havale_id;
        $("#nt").value = r.ozet || "";
        var ek = [];
        if (r.son_tarih_nedeni) ek.push("Son tarih önerisi: " + r.son_tarih_nedeni);
        if (r.havale_id && r.havale_nedeni) ek.push("Havale önerisi: " + r.havale_nedeni);
        $("#aim").innerHTML = '<div class="msg ok">Form dolduruldu; lütfen kontrol edin.' + (ek.length ? "<br>" + esc(ek.join(" · ")) : "") + "</div>";
      }).catch(fail).then(function () { b.disabled = false; b.textContent = "Yapay zekâ ile oku ve doldur"; });
    };
    $("#nf").onsubmit = function (e) {
      e.preventDefault();
      var f = $("#file").files[0];
      (f ? toB64(f) : Promise.resolve(null)).then(function (file) {
        return api("POST", "evrak", { type: "in", party: $("#party").value, subj: $("#subj").value, ref_no: $("#rn").value, ref_date: $("#rd").value,
          to_user: $("#tu") ? $("#tu").value : "", hnote: $("#hn") ? $("#hn").value : "", due: $("#du").value, note: $("#nt").value, file: file });
      }).then(function () { $("#form").innerHTML = ""; flash("Gelen evrak kaydedildi.", "ok"); done(); }).catch(fail);
    };
  });
}
function formOut(e, done) {
  var v = e || { kind: "Resmî yazı", party: "", subj: "", intro: "", dev: "", res: "", ek: "" };
  var rp = !e && window._reply ? window._reply : null; window._reply = null;
  v.rp = rp;
  if (rp) { v.party = rp.party; v.subj = "İlgi: " + rp.no + " sayılı yazınız (" + rp.subj + ")"; }
  var el = $("#form");
  kurumList().then(function (ks) { formOut2(e, done, v, el, ks); });
}
function formOut2(e, done, v, el, ks) {
  el.innerHTML = '<form class="card" id="of"><label for="kind">Evrak türü</label><select id="kind"><option' + (v.kind === "Resmî yazı" ? " selected" : "") + '>Resmî yazı</option><option' + (v.kind === "Dilekçe" ? " selected" : "") + '>Dilekçe</option></select>' +
    '<label for="party">Alıcı kurum / kişi</label><p class="sub">Yazıda birden çok satır istiyorsanız satırları noktalı virgül (;) ile ayırın. Örnek: T.C.; Milli Eğitim Bakanlığı; Ağrı İl Milli Eğitim Müdürlüğü</p><input id="party" required list="kl" autocomplete="off" value="' + esc(v.party) + '">' + kurumOpts(ks) +
    '<label for="subj">Konu</label><input id="subj" required value="' + esc(v.subj) + '">' +
    (me.ai ? '<div class="card" style="background:#f3f8ff"><label for="aib">Yapay zekâ ile yaz: ne yazılacağını kısaca anlatın</label><textarea id="aib" rows="3" placeholder="Örnek: Ağrı Valiliği\'nden ... konusunda izin istiyoruz, ... tarihli yazılarına cevap veriyoruz."></textarea><div class="acts"><button class="btn ghost" type="button" id="aig">Yapay zekâ ile yaz</button></div><div class="sub">Yazıyı imzalamadan önce mutlaka okuyup düzeltin. Eksik bilgiler [köşeli parantez] içinde kalır.</div></div>' : "") +
    '<label for="dev">Evrak metni</label><textarea id="dev" rows="14" placeholder="Evrakın metnini buraya yazın. Paragraflar arasında bir satır boşluk bırakın.">' + esc([v.intro, v.dev, v.res].filter(Boolean).join("\n\n")) + "</textarea>" +
    '<label for="ek">Ekler</label><input id="ek" placeholder="Varsa: Ek-1 ..." value="' + esc(v.ek) + '">' +
    '<div class="acts"><button class="btn" type="submit">Kaydet</button><button class="btn ghost" type="button" id="pvb">Önizleme (kaydetmeden)</button><button class="btn ghost" type="button" id="cn">Vazgeç</button></div></form><div id="pv"></div>';

  $("#pvb").onclick = function () {
    if (!$("#party").value.trim() && !$("#dev").value.trim()) return flash("Önizleme için önce alıcıyı ve metni yazın.", "bad");
    usersLite().then(function (us) {
      var fin = us.filter(function (u) { return u.final; })[0], d = new Date(), p2 = function (n) { return (n < 10 ? "0" : "") + n; };
      var pe = { kind: $("#kind").value, party: $("#party").value, subj: $("#subj").value, intro: "", dev: $("#dev").value, res: "", ek: $("#ek").value,
        no: e && !/^TASLAK-/.test(e.no) ? e.no : "ASL/G-" + d.getFullYear() + "/____", date: p2(d.getDate()) + "." + p2(d.getMonth() + 1) + "." + d.getFullYear(),
        status: "taslak", vcode: "", signers: fin ? [{ name: fin.name, title: fin.title || "" }] : [] };
      $("#pv").innerHTML = '<p class="sub">Önizleme (kaydedilmedi). Gerçek yazıda "TASLAK" filigranı olmaz; imzalandığında alta imza kutusu eklenir.</p><div id="pvarea">' + letter(pe) + "</div>";
      fitPaper(document.querySelector("#pv .paper"));
      $("#pv").scrollIntoView({ behavior: "smooth" });
    }).catch(fail);
  };
  $("#cn").onclick = function () { el.innerHTML = ""; };
  if ($("#aig")) $("#aig").onclick = function () {
    var b = this;
    if (!$("#subj").value.trim()) return flash("Önce konuyu yazın.", "bad");
    if ($("#dev").value.trim() && !confirm("Yazı alanındaki metnin yerine yapay zekâ metni gelecek. Devam edilsin mi?")) return;
    b.disabled = true; b.textContent = "Yazılıyor… (yarım dakika sürebilir)";
    api("POST", "ai/taslak", { kind: $("#kind").value, party: $("#party").value, subj: $("#subj").value, brief: $("#aib").value, reply_to: v.rp ? v.rp.id : undefined })
      .then(function (r) { $("#dev").value = r.text; $("#dev").focus(); }).catch(fail)
      .then(function () { b.disabled = false; b.textContent = "Yapay zekâ ile yaz"; });
  };
  $("#of").onsubmit = function (ev) {
    ev.preventDefault();
    var body = { type: "out", reply_to: v.rp ? v.rp.id : undefined, kind: $("#kind").value, party: $("#party").value, subj: $("#subj").value, intro: "", dev: $("#dev").value, res: "", ek: $("#ek").value };
    (e ? api("PATCH", "evrak/" + e.id, body) : api("POST", "evrak", body)).then(function () {
      el.innerHTML = ""; flash(e ? "Taslak güncellendi." : "Taslak oluşturuldu.", "ok"); done();
    }).catch(fail);
  };
}

/* ---------- evrak ayrıntısı ---------- */
function fitPaper(p) {
  /* Yazıyı A4'e sığdır: 12 punto'dan başlar, en fazla 10 punto'ya kadar küçülür; yine sığmazsa 2. sayfaya geçer. */
  if (!p) return;
  p.classList.remove("multi"); p.classList.add("fitm");
  var fs = 12; p.style.setProperty("--fs", fs + "pt");
  while (p.scrollHeight > p.clientHeight + 1 && fs > 10) { fs -= 0.25; p.style.setProperty("--fs", fs + "pt"); }
  var over = p.scrollHeight > p.clientHeight + 1;
  p.classList.remove("fitm");
  if (over) p.classList.add("multi");
}
function letter(e) {
  var dil = e.kind === "Dilekçe";
  var parts = [e.intro, e.dev, e.res].filter(Boolean).join("\n\n").replace(/\*\*/g, "").split(/\n\s*\n/).filter(function (p) { return p.trim(); }).map(function (p) { return "<p>" + esc(p.trim()) + "</p>"; }).join("");
  var last = e.signers.length ? e.signers[e.signers.length - 1] : null;
  var sig = "\n\n\n" + (last ? last.name + (last.title ? "\n" + last.title : "") : "");
  return '<div class="paper">' + (e.status === "taslak" ? '<div class="wm">TASLAK</div>' : "") +
    '<div class="lh"><img src="/logo.png" alt=""><div class="lt"><b>ASLANBAŞ YAPI</b><em>ENERJİ GIDA TARIM HAYVANCILIK ANONİM ŞİRKETİ</em><span>Ağrı Vergi Dairesi · VKN: 0890525025</span></div></div>' +
    '<div class="meta"><div class="sk">' + (dil ? "" : "<span>Sayı</span><span>: " + esc(e.no) + "</span>") + "<span>Konu</span><span>: " + esc(e.subj) + "</span></div><div class=\"dt\">" + esc(e.date) + "</div></div>" +
    '<div class="pto">' + esc(e.party.split(";").map(function (x) { return x.trim(); }).filter(Boolean).join("\n").toLocaleUpperCase("tr-TR")) + "" + "</div>" +
    '<div class="body">' + parts + '</div><div class="sig">' + esc(sig) + "</div>" +
    (e.ek ? '<div class="sub">Ek: ' + esc(e.ek) + "</div>" : "") +
    '<div class="ft">Sıtkıye Mahallesi Yaşar Kemal Caddesi No:27/17 Merkez / AĞRI<br>Tel: 0 532 704 50 30 · E-posta: aslanbasyapi@gmail.com · Web: www.aslanbasyapi.com<br>KEP: aslanbas.hs06.kep.tr · UETS: 25949-01947-94719 · Mersis No: 0089052502500017</div></div>';
}
function fileLinks(e, kind) {
  var l = e.attachments.filter(function (a) { return a.kind === kind; });
  return l.map(function (a) { return '<a href="/api/evrak/' + e.id + "/file/" + a.id + '">' + esc(a.name) + "</a>"; }).join(" · ");
}
function evrakView(id) {
  shell(null, '<div class="empty">Yükleniyor…</div>');
  api("GET", "evrak/" + id).then(function (d) {
    var e = d.evrak, mineC = e.created_by === me.id || has("yonet");
    var h = '<p><button class="btn ghost" id="back">← Listeye dön</button></p><div class="card"><div class="row"><span class="no">' + esc(e.no) +
      '</span><span class="tag ' + (e.status === "aktif" || e.status === "kapandi" ? "ok" : "") + '">' + ST[e.status] + "</span></div><div>" + esc(e.subj) +
      '</div><div class="sub">' + (e.type === "in" ? "Gönderen: " : "Alıcı: ") + esc(e.party) + " · " + esc(e.date) + " · Kaydeden: " + esc(e.created_by_name) + "</div>";
    if (e.type === "in") {
      h += (e.ref_no || e.ref_date ? '<div class="sub">Evrak sayısı / tarihi: ' + esc(e.ref_no) + " · " + esc(e.ref_date) + "</div>" : "") +
        (e.note ? '<div class="sub">' + esc(e.note) + "</div>" : "") +
        (e.attachments.length ? '<div class="sub">Dosya: ' + fileLinks(e, "ek") + "</div>" : "") +
        '<div class="sub">Havale: ' + esc(e.to_user_name || "Yok") + "</div>" + dueTag(e) +
        (e.replies && e.replies.length ? '<div class="sub">Cevap yazıları: ' + e.replies.map(function (r) { return '<a href="#/evrak/' + r.id + '">' + esc(r.no || "Taslak") + " (" + ST[r.status] + ")</a>"; }).join(" · ") + "</div>" : "") +
        '<div class="acts" id="acts"></div></div>';
      $("#view").innerHTML = h;
      var acts = $("#acts");
      if (has("havale")) {
        usersLite().then(function (us) {
          acts.insertAdjacentHTML("afterbegin", '<select id="tu"><option value="">Havale yok</option>' + us.map(function (u) { return '<option value="' + u.id + '"' + (u.name === e.to_user_name ? " selected" : "") + ">" + esc(u.name) + "</option>"; }).join("") + '</select><button class="btn ghost" id="hv">Havale et</button>');
          acts.insertAdjacentHTML("afterbegin", '<input id="hn2" placeholder="Havale notu (isteğe bağlı)" maxlength="500">');
          $("#hv").onclick = function () { api("PATCH", "evrak/" + id, { to_user: $("#tu").value, hnote: $("#hn2").value }).then(function () { evrakView(id); }).catch(fail); };
        });
      }
      if (e.hnote) $("#acts").insertAdjacentHTML("beforebegin", '<div class="sub">Havale notu: ' + esc(e.hnote) + "</div>");
      if (has("gelen_kaydet") || has("havale") || e.to_user === me.id) {
        acts.insertAdjacentHTML("beforeend", '<label class="sub" style="margin:0">Son tarih <input id="du2" type="date" value="' + esc(e.due || "") + '"></label><button class="btn ghost" id="dus">Tarihi kaydet</button>' +
          '<label class="btn ghost" style="cursor:pointer">Dosya ekle<input id="ekf" type="file" accept="application/pdf,image/*" hidden></label>');
        $("#dus").onclick = function () { api("PATCH", "evrak/" + id, { due: $("#du2").value }).then(function () { evrakView(id); }).catch(fail); };
        $("#ekf").onchange = function () { var f = this.files[0]; if (f) toB64(f).then(function (file) { return api("POST", "evrak/" + id + "/ek", { file: file }); }).then(function () { evrakView(id); }).catch(fail); };
      }
      if (has("giden_hazirla")) {
        acts.insertAdjacentHTML("beforeend", '<button class="btn" id="rpl">Cevap yaz</button>');
        $("#rpl").onclick = function () { window._reply = { id: e.id, no: e.no, subj: e.subj, party: e.party }; location.hash = "#/giden/yeni"; };
      }
      if (has("gelen_kaydet") || has("havale") || e.to_user === me.id) {
        acts.insertAdjacentHTML("beforeend", '<button class="btn ghost" id="st">' + (e.status === "acik" ? "Kapat" : "Yeniden aç") + "</button>");
        $("#st").onclick = function () { api("PATCH", "evrak/" + id, { status: e.status === "acik" ? "kapandi" : "acik" }).then(function () { evrakView(id); }).catch(fail); };
      }
    } else {
      h += "</div>";
      if (e.status === "taslak") {
        h += (e.ret_note ? '<div class="msg bad"><b>Önceki onay reddedildi.</b> ' + esc(e.ret_note) + "</div>" : "") + '<div class="acts" id="acts"></div><div id="form"></div><div id="signpanel"></div>';
      } else if (e.status === "imzada") {
        var nxt = e.signers.filter(function (s) { return !s.signed_at; })[0];
        var myTurn = nxt && nxt.user_id === me.id && nxt.kind === "imza" && has("imzala");
        var myApprove = nxt && nxt.kind === "onay" && (nxt.user_id === me.id || (me.approve_wait || []).indexOf(e.id) >= 0);
        h += '<div class="card"><b>Onay ve imza sırası</b><table><tr><th>Sıra</th><th>Kişi</th><th>Durum</th></tr>' +
          e.signers.map(function (s, i) { return "<tr><td>" + (i + 1) + "</td><td>" + esc(s.name) + ' <span class="tag">' + (s.kind === "onay" ? "Onay" : "İmza") + "</span>" + (s.title ? "<br><span class=\"sub\">" + esc(s.title) + "</span>" : "") + "</td><td>" + (s.signed_at ? (s.kind === "onay" ? "Onayladı" + (s.by ? " (vekil: " + esc(s.by) + ")" : "") + " · " : "İmzalandı · ") + fmt(s.signed_at) + (s.verified ? ' <span class="tag ok">Doğrulandı</span>' : "") : (s === nxt ? "Sırada" : "Bekliyor")) + "</td></tr>"; }).join("") +
          '</table><p class="sub">Evrak, son imzacı (' + esc(e.signers[e.signers.length - 1].name) + ") imzalayınca aktif olur.</p></div>";
        if (myApprove) {
          h += '<div class="card"><b>Onay sırası sizde</b><p class="sub">Yazıyı aşağıda okuyun. Uygunsa onaylayın; uygun değilse nedenini yazıp reddedin, yazı hazırlayana geri döner. Onay için e-imza kartı gerekmez.</p>' +
            '<label for="onote">Not (onayda isteğe bağlı, redde zorunlu)</label><input id="onote" maxlength="500" autocomplete="off">' +
            '<div class="acts"><button class="btn" id="onay">Onayla</button><button class="btn danger" id="ret">Reddet</button></div></div>';
        }
        if (myTurn) {
          var prev = fileLinks(e, "imzali");
          h += '<div class="card"><b>İmza sırası sizde</b><p class="sub">e-İmza kartınız bilgisayarda takılı olsun. “Kartla imzala”ya basınca açılan pencereye kart PIN\'inizi girin. PIN yalnızca o pencereye yazılır, sunucuya gönderilmez.</p>' +
            '<div class="acts"><button class="btn" id="kart">Kartla imzala</button></div><div id="kmsg"></div>' +
            '<details><summary class="sub">Kart yardımcısı olmadan, elle imzala</summary><ol class="steps"><li>' + (prev ? "Önceki imzalı dosyayı indirin: " + prev : "Aşağıdaki “Antetli yazdır” ile evrakı PDF olarak kaydedin.") +
            "</li><li>PDF'i e-imza kartınızla kendi imza programınızda imzalayın.</li><li>İmzalı PDF'i buraya yükleyin.</li></ol>" +
            '<input id="sf" type="file" accept="application/pdf"><div class="acts"><button class="btn ghost" id="sg">İmzalı PDF\'i yükle</button></div></details></div>';
        }
        if (mineC) h += '<div class="acts"><button class="btn danger" id="rv">Taslağa geri al</button></div>';
      } else {
        h += '<div class="card"><b>İmzalı dosyalar</b><div class="sub">' + (fileLinks(e, "imzali") || "Yok") + "</div></div>" +
          '<div class="card"><b>İmzalayanlar</b><table>' + e.signers.map(function (s) { return "<tr><td>" + esc(s.name) + (s.kind === "onay" ? " (onay)" : "") + "</td><td>" + fmt(s.signed_at) + (s.signed_at ? (s.kind === "onay" ? ' <span class="tag ok">Onayladı</span>' : s.verified ? ' <span class="tag ok">Doğrulandı</span>' : ' <span class="tag">Doğrulanmadı</span>') : "") + "</td></tr>"; }).join("") + "</table></div>";
        if (e.status === "aktif" && (mineC || has("giden_hazirla") || has("imzala"))) {
          h += '<div class="card"><b>E-posta ile gönder</b><p class="sub">İmzalı PDF, güvenli elektronik imzalı olarak alıcıya iletilir.</p>' +
            '<label for="mt">Alıcı e-posta (birden fazlaysa virgülle ayırın)</label><input id="mt" type="text" autocomplete="off" value="' + esc(e.party_email || "") + '">' +
            '<label for="mc">Bilgi (Cc, isteğe bağlı)</label><input id="mc" type="text" autocomplete="off">' +
            '<label for="mn">Mesaj (isteğe bağlı)</label><textarea id="mn" rows="2"></textarea>' +
            '<div class="acts">' + (e.mail_ready ? '<button class="btn" id="mgo">Sistemden gönder</button>' : "") +
            '<button class="btn ghost" id="mlo">Mail programımda aç</button></div><div id="mmsg"></div>' +
            '<p class="sub">“Mail programımda aç” seçeneğinde mesaj hazır gelir; imzalı PDF\'i yukarıdaki “İmzalı dosyalar”dan indirip eklemeniz gerekir.</p>' +
            (e.mails && e.mails.length ? '<table><tr><th>Tarih</th><th>Alıcı</th><th>Durum</th></tr>' + e.mails.map(function (m) { return "<tr><td>" + fmt(m.ts) + "</td><td>" + esc(m.to) + "</td><td>" + (m.ok ? '<span class="tag ok">Gönderildi</span>' : '<span class="tag bad">Hata</span>') + "</td></tr>"; }).join("") + "</table>" : "") + "</div>";
        }
      }
      if (e.status !== "taslak") {
        var sgd = e.signers.filter(function (s) { return s.signed_at && s.kind !== "onay"; });
        if (sgd.length && sgd.every(function (s) { return s.verified; })) h += '<div class="msg ok">Kayıtlı imzaların bütünlüğü ve imzalayan adı sunucuda doğrulandı. Sertifika zinciri ve iptal (OCSP) denetimi henüz yapılmıyor.</div>';
        else if (sgd.length) h += '<div class="msg">Bu evrakın imzası sunucuda doğrulanamadı (elle yüklenmiş ya da desteklenmeyen biçim). Sistem imza sırasını ve yetkiyi denetledi.</div>';
      }
      h += '<div class="acts" id="pbar"><button class="btn" id="pr">Antetli yazdır / PDF kaydet</button></div><div id="printarea">' + letter(e) + "</div>";
      $("#view").innerHTML = h;
      fitPaper(document.querySelector("#printarea .paper"));
      $("#pr").onclick = function () { window.print(); };
      if ($("#mlo")) {
        $("#mlo").onclick = function () {
          var to = $("#mt").value.trim();
          var body = "Sayın yetkili,\n\n" + ($("#mn").value.trim() ? $("#mn").value.trim() + "\n\n" : "") + e.date + " tarih ve " + e.no + " sayılı “" + e.subj + "” konulu yazımız ekte sunulmuştur.\n\n" +
            "Ek dosya güvenli elektronik imza ile imzalanmıştır (5070 sayılı Elektronik İmza Kanunu)." + (e.verify_url ? " Doğrulama: " + e.verify_url : "") + "\n\nSaygılarımızla,\nASLANBAŞ YAPI ENERJİ GIDA TARIM HAYVANCILIK ANONİM ŞİRKETİ";
          location.href = "mailto:" + encodeURIComponent(to).replace(/%2C|%3B/g, ",") + "?subject=" + encodeURIComponent(e.no + " - " + e.subj) + "&body=" + encodeURIComponent(body);
        };
      }
      if ($("#mgo")) {
        $("#mgo").onclick = function () {
          var b = this, mm = $("#mmsg");
          if (!$("#mt").value.trim()) { mm.innerHTML = '<div class="msg bad">Alıcı e-posta adresi yazın.</div>'; return; }
          if (!confirm("İmzalı evrak " + $("#mt").value.trim() + " adresine gönderilsin mi?")) return;
          b.disabled = true; mm.innerHTML = '<div class="msg">Gönderiliyor…</div>';
          api("POST", "evrak/" + id + "/mail", { to: $("#mt").value, cc: $("#mc").value, note: $("#mn").value })
            .then(function () { evrakView(id); flash("E-posta gönderildi.", "ok"); })
            .catch(function (x) { b.disabled = false; mm.innerHTML = '<div class="msg bad">' + esc(x.message) + "</div>"; });
        };
      }
      if ($("#kart")) {
        $("#kart").onclick = function () {
          var b = this, H = "http://127.0.0.1:8765", km = $("#kmsg");
          function say(t, k) { km.innerHTML = '<div class="msg ' + (k || "") + '">' + esc(t) + "</div>"; }
          b.disabled = true; say("İmza yardımcısına bağlanılıyor…");
          fetch(H + "/durum").then(function (r) { return r.json(); }).catch(function () {
            throw new Error("İmza yardımcısı çalışmıyor. Masaüstündeki “İmza Yardımcısı” kısayolunu çalıştırıp tekrar deneyin.");
          }).then(function () { return api("POST", "evrak/" + id + "/sign-token", {}); }).then(function (t) {
            say("Açılan pencerede kart PIN'inizi girin… (pencere görünmüyorsa görev çubuğuna bakın)");
            return fetch(H + "/imzala", { method: "POST", headers: { "Content-Type": "text/plain" },
              body: JSON.stringify({ server: location.origin, token: t.token, no: e.no, subj: e.subj }) }).then(function (r) { return r.json(); });
          }).then(function (r) {
            if (!r.ok) throw new Error(r.hata || "İmzalama başarısız.");
            evrakView(id); flash(r.active ? "Son imza atıldı, evrak aktif." : "İmzanız kaydedildi.", "ok");
          }).catch(function (x) { b.disabled = false; say(x.message, "bad"); });
        };
      }
      if (e.status === "taslak") {
        var acts = $("#acts");
        if (mineC) {
          acts.innerHTML = '<button class="btn ghost" id="ed">Düzenle</button>' + (me.final ? '<button class="btn" id="sq">Hemen imzaya geç</button>' : "") + '<button class="btn' + (me.final ? ' ghost' : '') + '" id="sd">İmzaya gönder</button>' + (/^TASLAK-/.test(e.no) ? '<button class="btn danger" id="dl">Taslağı sil</button>' : "");
          $("#ed").onclick = function () { formOut(e, function () { evrakView(id); }); };
          if ($("#dl")) $("#dl").onclick = function () { if (confirm("Taslak silinsin mi?")) api("DELETE", "evrak/" + id).then(function () { location.hash = "#/giden"; }).catch(fail); };
          if ($("#sq")) $("#sq").onclick = function () { this.disabled = true; api("POST", "evrak/" + id + "/send-to-sign", { signer_ids: [], approver_ids: [] }).then(function () { evrakView(id); }).catch(fail); };
          $("#sd").onclick = function () {
            usersLite().then(function (us) {
              var fin = us.filter(function (u) { return u.final; })[0], sel = [], ap = [];
              var cand = us.filter(function (u) { return u.can_sign && !u.final; });
              var apr = '<b>Onay (isteğe bağlı)</b><p class="sub">Önce onaylayacak kişiler. Onay için e-imza gerekmez. İşaretlediğiniz sırayla onaylarlar.</p>' +
                us.map(function (u) { return '<label class="perms"><span><input type="checkbox" class="apc" value="' + u.id + '"> ' + esc(u.name) + (u.title ? " · " + esc(u.title) : "") + "</span></label>"; }).join("");
              $("#signpanel").innerHTML = '<div class="card">' + apr + '</div><div class="card"><b>İmza sırası</b><p class="sub">İşaretlediğiniz sırayla imzalanır. Son imza her zaman ' + esc(fin ? fin.name : "son imzacı") + " tarafından atılır ve evrak o zaman aktif olur.</p>" +
                (cand.length ? cand.map(function (u) { return '<label class="perms"><span><input type="checkbox" value="' + u.id + '"> ' + esc(u.name) + (u.title ? " · " + esc(u.title) : "") + "</span></label>"; }).join("") : '<p class="sub">Başka imzalayacak personel yok.</p>') +
                '<p class="sub" id="ord"></p><div class="acts"><button class="btn" id="go">İmzaya gönder</button></div></div>';
              function show() { $("#ord").textContent = "Sıra: " + sel.map(function (i) { return us.filter(function (u) { return String(u.id) === i; })[0].name; }).concat([fin ? fin.name + " (son)" : "?"]).join(" → "); }
              show();
              Array.prototype.forEach.call($("#signpanel").querySelectorAll("input:not(.apc)"), function (cb) {
                cb.onchange = function () { if (cb.checked) sel.push(cb.value); else sel = sel.filter(function (x) { return x !== cb.value; }); show(); };
              });
              Array.prototype.forEach.call($("#signpanel").querySelectorAll(".apc"), function (cb) {
                cb.onchange = function () { if (cb.checked) ap.push(cb.value); else ap = ap.filter(function (x) { return x !== cb.value; }); };
              });
              $("#go").onclick = function () { var bos = [e.subj, e.intro, e.dev, e.res].join(" ").match(/\[[^\]\n]{1,60}\]/g); if (bos && !confirm("Metinde doldurulmamış boşluk var: " + bos.slice(0, 5).join(", ") + "\n\nYine de imzaya gönderilsin mi? (Hayır derseniz Düzenle ile tamamlayın.)")) return; api("POST", "evrak/" + id + "/send-to-sign", { signer_ids: sel, approver_ids: ap }).then(function () { evrakView(id); }).catch(fail); };
            });
          };
        }
      }
    }
    if ($("#onay")) {
      $("#onay").onclick = function () { this.disabled = true; api("POST", "evrak/" + id + "/approve", { note: $("#onote").value }).then(function () { evrakView(id); setTimeout(function () { flash("Onayınız kaydedildi.", "ok"); }, 400); }).catch(fail); };
      $("#ret").onclick = function () {
        if (!$("#onote").value.trim()) return flash("Reddetme nedenini yazın.", "bad");
        if (!confirm("Yazı reddedilip hazırlayana geri gönderilsin mi?")) return;
        api("POST", "evrak/" + id + "/reject", { note: $("#onote").value }).then(function () { location.hash = "#/ana"; flash("Yazı reddedildi, hazırlayana geri döndü.", "ok"); }).catch(fail);
      };
    }
    folderBar(e, id);
    $("#back").onclick = function () { location.hash = e.type === "in" ? "#/gelen" : "#/giden"; };
    if ($("#sg")) $("#sg").onclick = function () {
      var f = $("#sf").files[0]; if (!f) return flash("İmzalı PDF seçin.", "bad");
      if (!confirm("İmzalı PDF yüklenecek ve imza sırası bir sonraki kişiye geçecek. Devam edilsin mi?")) return;
      toB64(f).then(function (file) { return api("POST", "evrak/" + id + "/sign", { file: file }); })
        .then(function (r) { evrakView(id); flash(r.active ? "Son imza atıldı, evrak aktif." : "İmzanız kaydedildi.", "ok"); }).catch(fail);
    };
    if ($("#rv")) $("#rv").onclick = function () { api("POST", "evrak/" + id + "/revert").then(function () { evrakView(id); }).catch(fail); };
  }).catch(fail);
}

/* ---------- personel ---------- */
function permBoxes(sel, idp) {
  return '<div class="perms">' + PORDER.map(function (p) { return '<label><input type="checkbox" data-p="' + p + '" id="' + idp + p + '"' + (sel.indexOf(p) > -1 ? " checked" : "") + "> " + PL[p] + "</label>"; }).join("") + "</div>";
}
function readPerms(root) { return Array.prototype.filter.call(root.querySelectorAll("[data-p]"), function (c) { return c.checked; }).map(function (c) { return c.getAttribute("data-p"); }); }
function linkBox(link) {
  return '<div class="msg ok">Davet bağlantısı hazır (7 gün geçerli). Kişiye kendiniz iletin (ör. WhatsApp). Bağlantıyla o kişi kendi şifresini belirler:<div class="link">' + esc(link) + "</div></div>";
}
function staffView() {
  shell("personel", '<div class="acts"><button class="btn" id="add">Yeni personel</button></div><div id="form"></div><div id="reqs"></div><div id="list" class="card"><div class="empty">Yükleniyor…</div></div>');
  function loadReqs() {
    api("GET", "requests").then(function (d) {
      if (!d.requests.length) { $("#reqs").innerHTML = ""; return; }
      $("#reqs").innerHTML = '<div class="card"><b>Onay bekleyen hesap talepleri</b>' + d.requests.map(function (r) {
        return '<div class="card" data-r="' + r.id + '"><b>' + esc(r.name) + '</b><br><span class="sub">' + esc(r.email) + (r.title ? " · " + esc(r.title) : "") + " · " + fmt(r.ts) + "</span>" +
          "<label>Yetkiler</label>" + permBoxes(["gelen_gor"], "r" + r.id + "_") +
          '<div class="acts"><button class="btn" data-a="approve">Onayla</button><button class="btn danger" data-a="reject">Reddet</button></div></div>';
      }).join("") + "</div>";
      Array.prototype.forEach.call($("#reqs").querySelectorAll("button[data-a]"), function (b) {
        b.onclick = function () {
          var box = b.closest("[data-r]"), act = b.getAttribute("data-a");
          if (act === "reject" && !confirm("Bu talep silinecek. Devam edilsin mi?")) return;
          api("POST", "requests/" + box.getAttribute("data-r") + "/" + act, { perms: readPerms(box) }).then(function () {
            flash(act === "approve" ? "Personel onaylandı. Artık kendi şifresiyle girebilir." : "Talep reddedildi.", "ok");
            loadReqs(); load();
          }).catch(fail);
        };
      });
    }).catch(fail);
  }
  function load() {
    api("GET", "users").then(function (d) {
      $("#list").innerHTML = '<table><tr><th>Personel</th><th>Yetkiler</th><th>Durum</th><th></th></tr>' + d.users.map(function (u) {
        return "<tr><td><b>" + esc(u.name) + "</b><br><span class=\"sub\">" + esc(u.email) + (u.title ? " · " + esc(u.title) : "") + "</span>" + (u.final ? '<br><span class="tag ok">Son imzacı</span>' : "") + "</td><td class=\"sub\">" +
          (u.perms.map(function (p) { return PL[p]; }).join(", ") || "Yetki yok") + "</td><td>" + (!u.active ? '<span class="tag bad">Pasif</span>' : u.pending ? '<span class="tag">Davet bekliyor</span>' : '<span class="tag ok">Aktif</span>') +
          '</td><td><button class="btn ghost" data-id="' + u.id + '">Düzenle</button></td></tr>';
      }).join("") + "</table>";
      Array.prototype.forEach.call($("#list").querySelectorAll("button[data-id]"), function (b) {
        b.onclick = function () { editStaff(d.users.filter(function (u) { return String(u.id) === b.getAttribute("data-id"); })[0], load); };
      });
    }).catch(fail);
  }
  load(); loadReqs();
  $("#add").onclick = function () {
    $("#form").innerHTML = '<form class="card" id="sf"><label for="nm">Ad soyad</label><input id="nm" required><label for="em">E-posta</label><input id="em" type="email" required>' +
      '<label for="tt">Görev</label><input id="tt"><label>Yetkiler</label>' + permBoxes(["gelen_gor"], "n") +
      '<div class="acts"><button class="btn" type="submit">Personeli ekle</button><button class="btn ghost" type="button" id="cn">Vazgeç</button></div></form>';
    $("#cn").onclick = function () { $("#form").innerHTML = ""; };
    $("#sf").onsubmit = function (e) {
      e.preventDefault();
      api("POST", "users", { name: $("#nm").value, email: $("#em").value, title: $("#tt").value, perms: readPerms($("#sf")) }).then(function (r) {
        $("#form").innerHTML = linkBox(r.invite); flash("", ""); load();
      }).catch(fail);
    };
  };
}
function editStaff(u, reload) {
  $("#form").innerHTML = '<form class="card" id="ef"><b>' + esc(u.name) + '</b><label for="nm">Ad soyad</label><input id="nm" value="' + esc(u.name) + '"><label for="tt">Görev</label><input id="tt" value="' + esc(u.title) + '">' +
    "<label>Yetkiler</label>" + permBoxes(u.perms, "e") + '<label class="perms"><span><input type="checkbox" id="ac"' + (u.active ? " checked" : "") + "> Aktif (kapatılırsa girişi engellenir)</span></label>" +
    (u.final ? '<p class="sub">Bu kişi son imzacı.</p>' : '<label class="perms"><span><input type="checkbox" id="fn"> Son imzacı yap (evrakı en son bu kişi imzalar)</span></label>') +
    '<div class="acts"><button class="btn" type="submit">Kaydet</button><button class="btn ghost" type="button" id="ri">Şifre sıfırla / yeni davet</button><button class="btn ghost" type="button" id="r2">İki adımlı girişi sıfırla</button><button class="btn ghost" type="button" id="cn">Kapat</button></div><div id="inv"></div></form>';
  $("#cn").onclick = function () { $("#form").innerHTML = ""; };
  if ($("#r2")) $("#r2").onclick = function () { if (confirm("Kişinin iki adımlı girişi sıfırlanacak (telefonu kaybettiyse). Devam edilsin mi?")) api("POST", "users/" + u.id + "/2fa-reset").then(function () { flash("Sıfırlandı.", "ok"); reload(); }).catch(fail); };
  $("#ri").onclick = function () { if (confirm("Kişinin şifresi sıfırlanacak ve mevcut oturumu kapanacak. Devam edilsin mi?")) api("POST", "users/" + u.id + "/reinvite").then(function (r) { $("#inv").innerHTML = linkBox(r.invite); reload(); }).catch(fail); };
  $("#ef").onsubmit = function (e) {
    e.preventDefault();
    var b = { name: $("#nm").value, title: $("#tt").value, perms: readPerms($("#ef")), active: $("#ac").checked };
    if ($("#fn") && $("#fn").checked) b.final = true;
    api("PATCH", "users/" + u.id, b).then(function () { $("#form").innerHTML = ""; flash("Personel güncellendi.", "ok"); reload(); }).catch(fail);
  };
}
function auditView() {
  shell("kayit", '<div class="card" id="al"><div class="empty">Yükleniyor…</div></div>');
  api("GET", "audit").then(function (d) {
    $("#al").innerHTML = "<table><tr><th>Zaman</th><th>Kişi</th><th>İşlem</th><th>Ayrıntı</th></tr>" + d.rows.map(function (r) {
      return "<tr><td>" + fmt(r.ts) + "</td><td>" + esc(r.user) + "</td><td>" + esc(r.action) + '</td><td class="sub">' + esc(r.detail) + "</td></tr>";
    }).join("") + "</table>";
  }).catch(fail);
}
function passView() {
  shell("sifre", '<form class="card" id="pf"><label for="o">Mevcut şifre</label><input id="o" type="password" autocomplete="current-password" required><label for="n">Yeni şifre (en az 10 karakter)</label><input id="n" type="password" autocomplete="new-password" minlength="10" required><div class="acts"><button class="btn" type="submit">Şifreyi değiştir</button></div></form>');
  $("#pf").onsubmit = function (e) {
    e.preventDefault();
    api("POST", "me/password", { old: $("#o").value, "new": $("#n").value }).then(function () { $("#pf").reset(); flash("Şifre değiştirildi.", "ok"); }).catch(fail);
  };
  vekaletUI();
  twoFA();
}
function vekaletUI() {
  var box = document.createElement("div"); box.className = "card"; box.id = "vk";
  $("#view").appendChild(box);
  Promise.all([api("GET", "vekalet"), usersLite()]).then(function (rs) {
    var d = rs[0], us = rs[1].filter(function (u) { return u.id !== me.id; });
    var tr = function (x) { return x.start.split("-").reverse().join(".") + " – " + x.end.split("-").reverse().join("."); };
    box.innerHTML = '<b>Vekâlet</b><p class="sub">Yokken onay ve havale işlerinizi bir kişiye devredin. Vekil, seçtiğiniz tarihler arasında onayınızı bekleyen yazıları sizin adınıza onaylayabilir ve size havale edilen evrakları görür. <b>e-İmza yetkisini kapsamaz</b>: imza yalnızca kartın sahibi tarafından atılır.</p>' +
      (d.verdigim.length ? "<table><tr><th>Vekil</th><th>Tarih</th><th></th></tr>" + d.verdigim.map(function (x) { return "<tr><td>" + esc(x.to) + "</td><td>" + tr(x) + '</td><td><button class="btn ghost vki" data-i="' + x.id + '">İptal</button></td></tr>'; }).join("") + "</table>" : "") +
      (d.bana.length ? '<p class="sub">Size verilen vekâletler: ' + d.bana.map(function (x) { return esc(x.from) + " (" + tr(x) + ")"; }).join(", ") + "</p>" : "") +
      '<label for="vt">Vekil</label><select id="vt"><option value="">Seçin</option>' + us.map(function (u) { return '<option value="' + u.id + '">' + esc(u.name) + "</option>"; }).join("") + "</select>" +
      '<label for="vs">Başlangıç</label><input id="vs" type="date"><label for="ve">Bitiş</label><input id="ve" type="date">' +
      '<div class="acts"><button class="btn" id="vg">Vekâlet ver</button></div>';
    $("#vg").onclick = function () {
      api("POST", "vekalet", { to_user: $("#vt").value, start: $("#vs").value, end: $("#ve").value }).then(function () { flash("Vekâlet verildi, vekile e-posta gitti.", "ok"); passView(); }).catch(fail);
    };
    Array.prototype.forEach.call(box.querySelectorAll(".vki"), function (b) {
      b.onclick = function () { if (confirm("Vekâlet iptal edilsin mi?")) api("DELETE", "vekalet/" + b.getAttribute("data-i")).then(function () { passView(); }).catch(fail); };
    });
  }).catch(function () {});
}
function twoFA() {
  var box = document.createElement("div"); box.className = "card"; box.id = "tf"; $("#view").appendChild(box);
  var locked = me.final || has("yonet");
  function chooser(extra) {
    box.innerHTML = '<h3>İki adımlı giriş: <span class="tag ' + (me.mfa ? "ok" : "bad") + '">' + (me.mfa === "mail" ? "AÇIK (E-posta)" : me.mfa === "app" ? "AÇIK (Telefon uygulaması)" : "KAPALI") + "</span></h3>" +
      (me.must_2fa ? '<div class="msg bad">Hesabınız için iki adımlı giriş zorunlu. Devam etmek için aşağıdan bir yöntem seçin.</div>' : "") +
      '<p class="sub">Şifrenize ek olarak ikinci bir doğrulama istenir; şifreniz çalınsa bile hesabınıza girilemez. Güvendiğiniz bilgisayarda 30 gün tekrar sormaz.</p>' +
      '<div class="acts"><button class="btn" id="mm">E-posta ile doğrula (kolay)</button><button class="btn ghost" id="ma">Telefon uygulaması ile</button></div><div id="tx"></div>';
    $("#mm").onclick = mailSetup; $("#ma").onclick = appSetup;
  }
  function mailSetup() {
    api("POST", "me/2fa/mail/start").then(function (d) {
      $("#tx").innerHTML = '<p>' + esc(d.to) + ' adresine 6 haneli kod gönderdik.</p><label for="mc2">Kodu yazın</label><input id="mc2" inputmode="numeric" maxlength="8" autocomplete="off"><div class="acts"><button class="btn" id="me2">Doğrula ve aç</button></div>';
      $("#me2").onclick = function () { api("POST", "me/2fa/mail/enable", { code: $("#mc2").value }).then(function () { me.mfa = "mail"; me.totp = false; me.must_2fa = false; draw(); flash("İki adımlı giriş açıldı. Artık girişte e-postanıza kod gelecek.", "ok"); }).catch(fail); };
    }).catch(fail);
  }
  function appSetup() {
    api("POST", "me/2fa/setup").then(function (d) {
      $("#tx").innerHTML = '<ol><li>Telefona Google Authenticator veya Microsoft Authenticator yükleyin.</li><li><b>+</b> ile <b>QR kodu tara</b> deyin.</li></ol><div class="qrbox">' + d.qr + '</div><p class="sub">Tarayamazsanız anahtarı elle girin: <code>' + esc(d.secret) + '</code></p>' +
        '<label for="tc">Uygulamadaki 6 haneli kodu yazın</label><input id="tc" inputmode="numeric" maxlength="8" autocomplete="off"><div class="acts"><button class="btn" id="te">Doğrula ve aç</button></div>';
      $("#te").onclick = function () { api("POST", "me/2fa/enable", { code: $("#tc").value }).then(function () { me.mfa = "app"; me.totp = true; me.must_2fa = false; draw(); flash("İki adımlı giriş açıldı.", "ok"); }).catch(fail); };
    }).catch(fail);
  }
  function draw() {
    if (!me.mfa) return chooser();
    box.innerHTML = '<h3>İki adımlı giriş: <span class="tag ok">' + (me.mfa === "mail" ? "AÇIK (E-posta)" : "AÇIK (Telefon uygulaması)") + "</span></h3>" +
      '<p class="sub">Girişte ikinci doğrulama istenir. "Bu bilgisayara güven" dediğiniz cihazda 30 gün sorulmaz.</p>' +
      '<div class="acts"><button class="btn ghost" id="fg">Güvendiğim bilgisayarları unut</button><button class="btn ghost" id="sw">Yöntemi değiştir</button></div><div id="tx"></div>' +
      (locked ? '<p class="sub">Yönetici ve imza yetkilisi hesaplarında tamamen kapatılamaz.</p>' :
        '<details><summary>Kapat</summary><label for="dp">Şifreniz</label><input id="dp" type="password" autocomplete="current-password"><div class="acts"><button class="btn ghost" id="dg">İki adımlı girişi kapat</button></div></details>');
    $("#fg").onclick = function () { api("POST", "me/2fa/forget").then(function () { flash("Güvenilen bilgisayarlar silindi. Bir sonraki girişte kod istenecek.", "ok"); }).catch(fail); };
    $("#sw").onclick = function () { $("#tx").innerHTML = '<div class="acts"><button class="btn" id="mm">E-posta ile</button><button class="btn ghost" id="ma">Telefon uygulaması ile</button></div><div id="tx2"></div>'; $("#mm").onclick = function () { $("#tx").id = "tx0"; $("#tx2").id = "tx"; mailSetup(); }; $("#ma").onclick = function () { $("#tx").id = "tx0"; $("#tx2").id = "tx"; appSetup(); }; };
    var g = $("#dg"); if (g) g.onclick = function () { api("POST", "me/2fa/disable", { password: $("#dp").value }).then(function () { me.mfa = ""; me.totp = false; me.must_2fa = locked; draw(); flash("Kapatıldı.", "ok"); }).catch(fail); };
  }
  draw();
}

/* ---------- ana sayfa ---------- */
function ico(n) {
  var p = { gelen: "M4 4h16v12h-5l-3 3-3-3H4z", giden: "M3 11l18-8-8 18-2-8z", klasor: "M3 6h6l2 2h10v11H3z", kurum: "M4 21V8l8-5 8 5v13h-5v-6H9v6z", imza: "M4 20c4 0 4-10 8-10s2 8 8 8", sistem: "M12 8a4 4 0 100 8 4 4 0 000-8zM3 12h3M18 12h3M12 3v3M12 18v3" };
  return '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="' + (p[n] || p.klasor) + '"/></svg>';
}
function homeView() {
  var sw = me.sign_wait || [];
  var hr = new Date().getHours(), hi = hr < 6 ? "İyi geceler" : hr < 12 ? "Günaydın" : hr < 18 ? "İyi günler" : "İyi akşamlar";
  shell("ana", '<div class="empty">Yükleniyor…</div>');
  api("GET", "ozet").then(function (d) {
    var tile = function (n, t, href, cls) { return '<a class="tile ' + (cls || "") + '" href="#/' + href + '"><b>' + n + "</b><span>" + t + "</span></a>"; };
    var h = '<div class="hero"><div><div class="hello">' + hi + ", " + esc(me.name.split(" ")[0]) + '</div><div class="sub">' + new Date().toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long", year: "numeric" }) + "</div></div></div>" +
      '<div class="tiles tiles3">' + tile(d.gelen_acik, "Açık gelen evrak", "gelen") + (has("imzala") ? tile(d.bekleyen.length, "İmzanızı bekleyen", "giden", d.bekleyen.length ? "hot" : "") : "") + tile(d.ay_aktif, "Bu ay tamamlanan giden", "giden") + "</div>";
    var sec = function (t, l, id, href) {
      if (!l.length) return "";
      return '<h3 class="sec">' + t + " (" + l.length + ')</h3><div class="llist hl" id="' + id + '">' + l.slice(0, 5).map(rowHTML).join("") + "</div>" +
        (l.length > 5 ? '<div class="more"><a href="#/' + href + '">+' + (l.length - 5) + " evrak daha · tümünü gör</a></div>" : "");
    };
    var dk = [["Süresi geçen", d.geciken, "gelen"], ["Son tarihi yaklaşan", d.yaklasan, "gelen"], ["Bana havale edilen", d.bana, "gelen"], ["Onayınızı bekleyen", d.onay, "giden"], ["İmza sürecindeki yazı", d.imzada, "giden"], ["Taslaklarım", d.taslak, "giden"]].filter(function (x) { return x[1] && x[1].length; });
    if (dk.length) h += '<h3 class="sec">Dikkat isteyenler</h3><div class="tiles">' + dk.map(function (x) { return tile(x[1].length, x[0], x[2], "hot"); }).join("") + "</div>";
    else h += '<div class="msg ok">Bekleyen iş yok. Gelen ve Giden sayfalarından evraklara ulaşabilirsiniz.</div>';
    $("#view").innerHTML = h;
    Array.prototype.forEach.call(document.querySelectorAll(".hl .lrow"), function (el) {
      function go() { location.hash = "#/evrak/" + el.getAttribute("data-id"); }
      el.onclick = go; el.onkeydown = function (ev) { if (ev.key === "Enter") go(); };
    });
  }).catch(function (x) { $("#view").innerHTML = '<div class="msg bad">' + esc(x.message) + "</div>"; });
}

/* ---------- dosyalar (klasörler) ---------- */
function klasorList() { return api("GET", "klasorler"); }
function dosyalarView() {
  shell("dosyalar", '<div class="empty">Yükleniyor…</div>');
  klasorList().then(function (d) {
    var canMk = has("gelen_kaydet") || has("giden_hazirla") || has("arsiv");
    var card = function (id, n, c) { return '<a class="folder" href="#/dosyalar/' + id + '">' + ico("klasor") + '<span class="fn">' + esc(n) + '</span><span class="fc">' + c + " evrak</span></a>"; };
    $("#view").innerHTML = (canMk ? '<form class="bar" id="kf"><input id="kn" placeholder="Yeni klasör adı" maxlength="80" autocomplete="off"><button class="btn" type="submit">Klasör oluştur</button></form>' : "") +
      '<div class="folders">' + d.klasorler.map(function (k) { return card(k.id, k.name, k.count); }).join("") + card(0, "Klasörsüz", d.klasorsuz) + "</div>" +
      (d.klasorler.length ? "" : '<p class="sub">Henüz klasör yok. Bir evrakı açıp “Klasör” seçeneğinden klasöre alabilirsiniz.</p>');
    if ($("#kf")) $("#kf").onsubmit = function (e) {
      e.preventDefault();
      api("POST", "klasorler", { name: $("#kn").value }).then(function () { dosyalarView(); flash("Klasör oluşturuldu.", "ok"); }).catch(fail);
    };
  }).catch(fail);
}
function klasorView(id) {
  shell("dosyalar", '<div class="empty">Yükleniyor…</div>');
  Promise.all([klasorList(), api("GET", "evrak?klasor=" + id)]).then(function (rs) {
    var k = rs[0].klasorler.filter(function (x) { return String(x.id) === String(id); })[0];
    if (id !== "0" && !k) { $("#view").innerHTML = '<div class="msg bad">Klasör bulunamadı.</div>'; return; }
    var canEd = id !== "0" && (has("gelen_kaydet") || has("giden_hazirla") || has("arsiv"));
    $("#view").innerHTML = '<p><button class="btn ghost" id="back">← Dosyalar</button></p><div class="card"><div class="row"><span class="no">' + ico("klasor") + " " + esc(k ? k.name : "Klasörsüz evraklar") + '</span><span class="sub">' + rs[1].evrak.length + " evrak</span></div>" +
      (canEd ? '<div class="acts"><input id="rn" value="' + esc(k.name) + '" maxlength="80" style="flex:1;min-width:140px"><button class="btn ghost" id="rb">Adı değiştir</button>' + (has("yonet") ? '<button class="btn danger" id="kdl">Klasörü sil</button>' : "") + "</div>" : "") + "</div>" +
      '<div id="kl">' + (rs[1].evrak.map(itemHTML).join("") || '<div class="empty">Bu klasörde evrak yok.</div>') + "</div>";
    $("#back").onclick = function () { location.hash = "#/dosyalar"; };
    if ($("#rb")) $("#rb").onclick = function () { api("PATCH", "klasorler/" + id, { name: $("#rn").value }).then(function () { klasorView(id); flash("Kaydedildi.", "ok"); }).catch(fail); };
    if ($("#kdl")) $("#kdl").onclick = function () { if (confirm("Klasör silinsin mi? İçindeki evraklar silinmez, klasörsüz kalır.")) api("DELETE", "klasorler/" + id).then(function () { location.hash = "#/dosyalar"; }).catch(fail); };
    Array.prototype.forEach.call(document.querySelectorAll("#kl .item"), function (el) {
      function go() { location.hash = "#/evrak/" + el.getAttribute("data-id"); }
      el.onclick = go; el.onkeydown = function (ev) { if (ev.key === "Enter") go(); };
    });
  }).catch(fail);
}
function folderBar(e, id) {
  var first = $("#view .card"); if (!first) return;
  if (has("arsiv") && e.status !== "taslak") {
    first.insertAdjacentHTML("afterend", '<div class="card"><label for="sk">Saklama süresi</label><select id="sk">' + [["", "Belirlenmedi"], ["2", "2 yıl"], ["5", "5 yıl"], ["10", "10 yıl"], ["15", "15 yıl"], ["20", "20 yıl"], ["30", "30 yıl"], ["0", "Sürekli"]].map(function (o) { return '<option value="' + o[0] + '"' + (String(e.sakla == null ? "" : e.sakla) === o[0] ? " selected" : "") + ">" + o[1] + "</option>"; }).join("") + "</select></div>");
    $("#sk").onchange = function () { api("PATCH", "evrak/" + id, { sakla: this.value === "" ? null : Number(this.value) }).then(function () { flash("Saklama süresi kaydedildi.", "ok"); }).catch(fail); };
  }
  klasorList().then(function (d) {
    var cur = e.klasor_id || 0;
    first.insertAdjacentHTML("afterend", '<div class="card folderbar"><label for="fsel">Klasör</label><select id="fsel"><option value="0">Klasörsüz</option>' +
      d.klasorler.map(function (k) { return '<option value="' + k.id + '"' + (k.id === cur ? " selected" : "") + ">" + esc(k.name) + "</option>"; }).join("") + '<option value="new">+ Yeni klasör oluştur…</option></select><button class="btn ghost" id="fsv">Klasöre al</button><div id="fnew" hidden style="flex-basis:100%"><input id="fnm" placeholder="Yeni klasörün adı" maxlength="80" autocomplete="off"></div></div>');
    var kur = function () { return has("gelen_kaydet") || has("giden_hazirla") || has("arsiv") || has("yonet"); };
    if (!kur()) { var op = $("#fsel option[value=new]"); if (op) op.remove(); }
    $("#fsel").onchange = function () {
      var yeni = this.value === "new";
      $("#fnew").hidden = !yeni; $("#fsv").textContent = yeni ? "Oluştur ve klasöre al" : "Klasöre al";
      if (yeni) $("#fnm").focus();
    };
    $("#fsv").onclick = function () {
      var yeni = $("#fsel").value === "new";
      if (yeni) {
        if (!$("#fnm").value.trim()) return flash("Klasör adını yazın.", "bad");
        api("POST", "klasorler", { name: $("#fnm").value }).then(function (r) { return api("POST", "evrak/" + id + "/klasor", { klasor_id: r.id }); })
          .then(function () { evrakView(id); setTimeout(function () { flash("Klasör oluşturuldu ve evrak klasöre alındı.", "ok"); }, 400); }).catch(fail);
        return;
      }
      api("POST", "evrak/" + id + "/klasor", { klasor_id: Number($("#fsel").value) || null }).then(function () { flash("Klasör güncellendi.", "ok"); }).catch(fail);
    };
  }).catch(function () {});
}

/* ---------- sistem (yönetici) ---------- */
function saklamaCard() {
  api("GET", "saklama").then(function (d) {
    var el = $("#saklama"); if (!el) return;
    el.innerHTML = "<b>Saklama süresi</b><p class=\"sub\">Evrak sayfasından her evrağa saklama süresi verin. Süresi dolanlar burada listelenir; imha işlemi sizin onayınızla yapılır (sistem kendiliğinden silmez).</p>" +
      '<div class="msg">Süresi belirlenmemiş evrak: ' + d.ayarsiz + "</div>" +
      (d.dolan.length ? '<div class="msg bad"><b>Saklama süresi dolan ' + d.dolan.length + " evrak:</b></div>" + d.dolan.map(function (x) { return '<div class="sub"><a href="#/evrak/' + x.id + '">' + esc(x.no) + "</a> · " + esc(x.subj) + " · bitiş " + esc(x.bitis) + "</div>"; }).join("") : '<div class="msg ok">Süresi dolan evrak yok.</div>');
  }).catch(function () {});
}
function sistemView() {
  shell("sistem", '<div class="empty">Yükleniyor…</div>');
  api("GET", "sistem").then(function (d) {
    $("#view").innerHTML = '<div class="card"><div class="row"><span class="no">Sistem sürümü</span><span class="tag ok">' + esc(d.surum) + "</span></div>" +
      (d.sonuc ? '<div class="sub">Son güncelleme sonucu: ' + esc(d.sonuc) + "</div>" : "") + "</div>" +
      '<div class="card"><b>Güncelleme</b>' + (d.guncelleyici ? '<p class="sub">Size gönderilen güncelleme paketini (.tgz) seçip yükleyin. Sistem paketi denetler, yedeğini alır, uygular; açılmazsa önceki sürüme kendiliğinden döner. Bu sırada site birkaç saniye kapanır.</p>' +
        '<input id="uf" type="file" accept=".tgz,.gz,application/gzip"><div class="acts"><button class="btn" id="ug">Güncellemeyi yükle</button> <button class="btn ghost" id="ugk">Yeni sürüm var mı? (otomatik)</button></div><div id="umsg"></div><p class="sub">Sistem her gece 03:00-06:00 arasında yeni sürüm olup olmadığına kendisi bakar ve varsa kendisi kurar.</p>'
        : '<div class="msg bad">Otomatik güncelleme sunucuda henüz kurulu değil. Tek seferlik kurulum gerekir (size ayrıca anlatılacak).</div>') + "</div>" +
      '<div class="card" id="saklama"></div>' +
      '<div class="card"><b>Yedek</b><p class="sub">Her gece 03:00\'te veritabanının yerel kopyası alınır (son 14 gün tutulur). Sunucu bozulursa yerel kopya yetmez; bu yüzden <b>haftada bir</b> aşağıdaki düğmeyle tam yedeği bilgisayarınıza indirip güvenli bir yerde (harici disk, şifreli klasör) saklayın. Dosya evrakları ve veritabanını içerir; e-posta ve yapay zekâ şifreleri içermez.</p>' +
      '<div class="msg ok">Yerel yedek sayısı: ' + d.yedek.yerel_sayi + (d.yedek.son ? " · son: " + d.yedek.son.slice(6) + "." + d.yedek.son.slice(4, 6) + "." + d.yedek.son.slice(0, 4) : "") + '</div>' +
      '<div class="acts"><a class="btn" href="/api/sistem/yedek" download>Tam yedeği indir</a><button class="btn ghost" id="yal">Şimdi yerel yedek al</button></div></div>' +
      '<div class="card"><b>Yapay zekâ ile yazı yazma</b>' + (d.ai_ready ? '<div class="msg ok">Açık</div>' : '<div class="msg">Kapalı. Anahtar girilince giden yazı formunda “Yapay zekâ ile yaz” düğmesi çıkar.</div>') +
      '<p class="sub">Anthropic Console (console.anthropic.com) hesabından “API Keys” bölümünde oluşturulan anahtarı yapıştırın (sk-ant- ile başlar). Kullanım küçük bir ücrete tabidir. Yazı konusu ve notunuz yapay zekâ hizmetine gönderilir; gizli bilgi yazmayın. Kapatmak için kutuyu boş bırakıp kaydedin.</p>' +
      '<label for="ak">API anahtarı</label><input id="ak" type="password" autocomplete="new-password"><div class="acts"><button class="btn" id="aks">Dene ve kaydet</button></div><div id="amsg"></div></div>' +
      '<div class="card"><b>E-posta (Gmail) ayarı</b>' + (d.mail_ready ? '<div class="msg ok">Bağlı: ' + esc(d.mail_user) + "</div>" : '<div class="msg">Henüz ayarlanmadı. Evraklar “Sistemden gönder” ile yollanamaz.</div>') +
      '<p class="sub">Gmail hesabında “2 adımlı doğrulama” açıkken Google Hesabı → Güvenlik → “Uygulama şifreleri” bölümünden 16 haneli bir şifre alın ve aşağı yazın. Bu şifre yalnızca bu sunucuda saklanır.</p>' +
      '<label for="mu">Gmail adresi</label><input id="mu" type="email" autocomplete="off" value="' + esc(d.mail_user || "") + '"><label for="mp">Uygulama şifresi</label><input id="mp" type="password" autocomplete="new-password">' +
      '<div class="acts"><button class="btn" id="mk">Dene ve kaydet</button></div><div id="mmsg"></div></div>';
    $("#yal").onclick = function () { api("POST", "sistem/yedek-al").then(function () { sistemView(); flash("Yerel yedek alındı.", "ok"); }).catch(fail); };
    $("#aks").onclick = function () {
      var b = this; b.disabled = true; $("#amsg").innerHTML = '<div class="msg">Deneniyor…</div>';
      api("POST", "sistem/ai", { key: $("#ak").value }).then(function () { sistemView(); flash("Yapay zekâ ayarı kaydedildi.", "ok"); })
        .catch(function (x) { b.disabled = false; $("#amsg").innerHTML = '<div class="msg bad">' + esc(x.message) + "</div>"; });
    };
    $("#mk").onclick = function () {
      var b = this; b.disabled = true; $("#mmsg").innerHTML = '<div class="msg">Deneme maili gönderiliyor…</div>';
      api("POST", "sistem/mail", { user: $("#mu").value, password: $("#mp").value }).then(function () { sistemView(); flash("Mail ayarı kaydedildi, deneme maili gönderildi.", "ok"); })
        .catch(function (x) { b.disabled = false; $("#mmsg").innerHTML = '<div class="msg bad">' + esc(x.message) + "</div>"; });
    };
    saklamaCard();
    if ($("#ug")) $("#ugk").onclick = function () { var b = this; b.disabled = true; $("#umsg").innerHTML = '<div class="msg">Denetleniyor…</div>'; api("POST", "sistem/gunc-kontrol").then(function (r) { b.disabled = false; $("#umsg").innerHTML = '<div class="msg ' + (/^(REDDED|GitHub)/.test(r.mesaj) ? "bad" : "ok") + '">' + esc(r.mesaj) + "</div>"; if (/^Yeni sürüm/.test(r.mesaj)) setTimeout(function () { location.reload(); }, 25000); }).catch(function (x) { b.disabled = false; $("#umsg").innerHTML = '<div class="msg bad">' + esc(x.message || "Hata") + "</div>"; }); };
      $("#ug").onclick = function () {
      var f = $("#uf").files[0], um = $("#umsg"); if (!f) return flash("Güncelleme dosyasını seçin.", "bad");
      if (!confirm("Sistem güncellensin mi? Site birkaç saniye kapanacak.")) return;
      this.disabled = true; um.innerHTML = '<div class="msg">Yükleniyor…</div>';
      toB64(f).then(function (file) { return api("POST", "sistem/guncelle", { data: file.data }); }).then(function (r) {
        um.innerHTML = '<div class="msg">Paket kabul edildi (sürüm ' + esc(r.yeni) + "). Uygulanıyor, lütfen bekleyin…</div>";
        var n = 0, t = setInterval(function () {
          n++;
          api("GET", "sistem").then(function (s) {
            if (s.sonuc && !s.bekliyor) {
              clearInterval(t);
              um.innerHTML = '<div class="msg ' + (/^TAMAM/.test(s.sonuc) ? "ok" : "bad") + '">' + esc(s.sonuc) + "</div>";
              if (/^TAMAM/.test(s.sonuc)) setTimeout(function () { location.reload(); }, 1500);
            }
          }).catch(function () {});
          if (n > 40) { clearInterval(t); um.innerHTML = '<div class="msg bad">Güncelleme beklenenden uzun sürdü. Sayfayı yenileyip Sistem sekmesindeki sonuca bakın.</div>'; }
        }, 3000);
      }).catch(function (x) { $("#ug").disabled = false; um.innerHTML = '<div class="msg bad">' + esc(x.message) + "</div>"; });
    };
  }).catch(fail);
}

/* ---------- kurumlar rehberi ---------- */
function kurumlarView() {
  shell("kurumlar", '<div class="bar"><input id="q" type="search" placeholder="Kurum ara"></div><div id="list"><div class="empty">Yükleniyor…</div></div>');
  kurumList().then(function (ks) {
    function draw() {
      var t = $("#q").value.trim().toLocaleLowerCase("tr-TR");
      var l = ks.filter(function (k) { return !t || k.name.toLocaleLowerCase("tr-TR").indexOf(t) >= 0 || (k.email || "").toLowerCase().indexOf(t) >= 0; });
      $("#list").innerHTML = l.map(function (k) { return '<div class="card item" tabindex="0" role="link" data-id="' + k.id + '"><div class="row"><span class="no">' + esc(k.name) + '</span></div><div class="sub">' + (k.email ? esc(k.email) : "E-posta kayıtlı değil") + "</div></div>"; }).join("") || '<div class="empty">Kurum bulunamadı. Evrak kaydettikçe kurumlar burada otomatik birikir.</div>';
      Array.prototype.forEach.call(document.querySelectorAll(".item"), function (el) {
        function go() { location.hash = "#/kurumlar/" + el.getAttribute("data-id"); }
        el.onclick = go; el.onkeydown = function (ev) { if (ev.key === "Enter") go(); };
      });
    }
    $("#q").oninput = draw; draw();
  });
}
function kurumView(id) {
  shell("kurumlar", '<div class="empty">Yükleniyor…</div>');
  kurumList().then(function (ks) {
    var k = ks.filter(function (x) { return String(x.id) === String(id); })[0];
    if (!k) { $("#view").innerHTML = '<div class="msg bad">Kurum bulunamadı.</div>'; return; }
    $("#view").innerHTML = '<p><button class="btn ghost" id="back">← Kurumlar</button></p><div class="card"><div class="row"><span class="no">' + esc(k.name) + "</span></div>" +
      '<label for="ke">E-posta (birden fazlaysa virgülle ayırın)</label><input id="ke" type="text" autocomplete="off" value="' + esc(k.email || "") + '">' +
      '<div class="acts"><button class="btn" id="ks">E-postayı kaydet</button>' + (has("yonet") ? '<button class="btn danger" id="kd">Rehberden sil</button>' : "") + '</div></div>' +
      '<h3 class="sec">Bu kurumla yazışmalar</h3><div id="kl2"><div class="empty">Yükleniyor…</div></div>';
    $("#back").onclick = function () { location.hash = "#/kurumlar"; };
    $("#ks").onclick = function () { api("PATCH", "kurumlar/" + id, { email: $("#ke").value }).then(function () { flash("Kaydedildi.", "ok"); }).catch(fail); };
    if ($("#kd")) $("#kd").onclick = function () { if (confirm("Kurum rehberden silinsin mi? Evraklar silinmez.")) api("DELETE", "kurumlar/" + id).then(function () { location.hash = "#/kurumlar"; }).catch(fail); };
    Promise.all([api("GET", "evrak?type=in&q=" + encodeURIComponent(k.name)), api("GET", "evrak?type=out&q=" + encodeURIComponent(k.name))]).then(function (rs) {
      var all = rs[0].evrak.concat(rs[1].evrak).filter(function (e) { return (e.party || "").toLocaleLowerCase("tr-TR") === k.name.toLocaleLowerCase("tr-TR"); });
      all.sort(function (a, b) { return b.id - a.id; });
      $("#kl2").innerHTML = all.map(itemHTML).join("") || '<div class="empty">Bu kurumla kayıtlı evrak yok.</div>';
      Array.prototype.forEach.call(document.querySelectorAll("#kl2 .item"), function (el) {
        function go() { location.hash = "#/evrak/" + el.getAttribute("data-id"); }
        el.onclick = go; el.onkeydown = function (ev) { if (ev.key === "Enter") go(); };
      });
    }).catch(fail);
  });
}

/* ---------- genel arama ---------- */
function initSearch() {
  var inp = $("#gq"), box = $("#gres"), t = 0, seq = 0;
  if (!inp) return;
  function hide() { box.hidden = true; }
  function go(q) { hide(); location.hash = "#/ara/" + encodeURIComponent(q); }
  inp.oninput = function () {
    clearTimeout(t);
    var q = inp.value.trim();
    if (!q) return hide();
    t = setTimeout(function () {
      var my = ++seq;
      api("GET", "evrak?type=all&q=" + encodeURIComponent(q)).then(function (d) {
        if (my !== seq || inp.value.trim() !== q) return;
        var l = d.evrak;
        box.innerHTML = l.slice(0, 7).map(function (e) {
          return '<a class="gi" href="#/evrak/' + e.id + '"><b>' + esc(e.no) + '</b><span>' + esc(e.subj) + "</span><em>" + (e.type === "in" ? "Gelen · " : "Giden · ") + esc(e.party) + " · " + ST[e.status] + "</em></a>";
        }).join("") + (l.length ? '<a class="gall" href="#/ara/' + encodeURIComponent(q) + '">Tüm sonuçları gör (' + l.length + ")</a>" : '<div class="gnone">Sonuç bulunamadı.</div>');
        box.hidden = false;
      }).catch(hide);
    }, 200);
  };
  $("#gsf").onsubmit = function (e) { e.preventDefault(); if (inp.value.trim()) go(inp.value.trim()); };
  inp.onkeydown = function (e) { if (e.key === "Escape") { hide(); inp.blur(); } };
  box.onclick = function () { setTimeout(hide, 0); };
  document.addEventListener("click", function (e) { if (!$("#gsf") || !$("#gsf").contains(e.target)) hide(); });
}
function araView(q) {
  shell("", '<div class="empty">Aranıyor…</div>');
  $("#gq").value = q;
  api("GET", "evrak?type=all&q=" + encodeURIComponent(q)).then(function (d) {
    $("#view").innerHTML = '<h3 class="sec">“' + esc(q) + '” için ' + d.evrak.length + " sonuç</h3><div id=\"ar\">" + (d.evrak.map(itemHTML).join("") || '<div class="empty">Sonuç bulunamadı. Sayı, kurum adı, konu veya yazının içinden bir kelime deneyin.</div>') + "</div>";
    Array.prototype.forEach.call(document.querySelectorAll("#ar .item"), function (el) {
      function go() { location.hash = "#/evrak/" + el.getAttribute("data-id"); }
      el.onclick = go; el.onkeydown = function (ev) { if (ev.key === "Enter") go(); };
    });
  }).catch(fail);
}

/* ---------- yönlendirme ---------- */
function route() {
  var h = (location.hash || "").replace(/^#\/?/, "").split("/");
  if (h[0] === "davet" && h[1]) return inviteView(h[1]);
  if (h[0] === "talep") return requestView();
  return api("GET", "me").then(function (d) { me = d.user; if (me.must_2fa && h[0] !== "sifre" && h[0] !== "sistem") { location.hash = "#/sifre"; return; } show(h); }).catch(function () { me = null; loginView(); });
}
function show(h) {
  if (h[0] === "gelen") return listView("in", h[1] === "yeni");
  if (h[0] === "giden") return listView("out", h[1] === "yeni");
  if (h[0] === "evrak" && /^\d+$/.test(h[1] || "")) return evrakView(h[1]);
  if (h[0] === "personel" && has("yonet")) return staffView();
  if (h[0] === "kayit" && has("yonet")) return auditView();
  if (h[0] === "sistem" && has("yonet")) return sistemView();
  if (h[0] === "dosyalar") return /^\d+$/.test(h[1] || "") ? klasorView(h[1]) : dosyalarView();
  if (h[0] === "kurumlar") return h[1] && /^\d+$/.test(h[1]) ? kurumView(h[1]) : kurumlarView();
  if (h[0] === "sifre") return passView();
  if (h[0] === "ara") return araView(decodeURIComponent(h.slice(1).join("/") || ""));
  return homeView();
}
(function () {
  var act = 0, last = Date.now();
  ["click", "keydown", "touchstart", "mousemove"].forEach(function (ev) { document.addEventListener(ev, function () { act = Date.now(); }, { passive: true }); });
  setInterval(function () { if (me && act > last) { last = Date.now(); api("GET", "me").catch(function () {}); } }, 4 * 60 * 1000);
})();
window.addEventListener("hashchange", route);
route();
})();
