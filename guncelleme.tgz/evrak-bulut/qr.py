"""Küçük QR kod üretici (yalnızca standart kütüphane). Bayt kipi, hata düzeltme M, sürüm 1-10."""

# sürüm: (toplam kod sözcüğü, blok başına EC, [(blok sayısı, blok veri sözcüğü), ...])
_V = {1: (26, 10, [(1, 16)]), 2: (44, 16, [(1, 28)]), 3: (70, 26, [(1, 44)]), 4: (100, 18, [(2, 32)]),
      5: (134, 24, [(2, 43)]), 6: (172, 16, [(4, 27)]), 7: (196, 18, [(4, 31)]),
      8: (242, 22, [(2, 38), (2, 39)]), 9: (292, 22, [(3, 36), (2, 37)]), 10: (346, 26, [(4, 43), (1, 44)])}
_AL = {1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34], 7: [6, 22, 38], 8: [6, 24, 42],
       9: [6, 26, 46], 10: [6, 28, 50]}

_EXP = [0] * 512
_LOG = [0] * 256
_x = 1
for _i in range(255):
    _EXP[_i] = _x
    _LOG[_x] = _i
    _x <<= 1
    if _x & 0x100:
        _x ^= 0x11D
for _i in range(255, 512):
    _EXP[_i] = _EXP[_i - 255]


def _mul(a, b):
    return 0 if a == 0 or b == 0 else _EXP[_LOG[a] + _LOG[b]]


def _rs(data, n):
    g = [1]
    for i in range(n):
        ng = [0] * (len(g) + 1)
        for j, c in enumerate(g):
            ng[j] ^= c
            ng[j + 1] ^= _mul(c, _EXP[i])
        g = ng
    rem = [0] * n
    for b in data:
        f = b ^ rem[0]
        rem = rem[1:] + [0]
        for i in range(n):
            rem[i] ^= _mul(g[i + 1], f)
    return rem


def _bch(v, poly, bits_total, bits_data):
    r = v << (bits_total - bits_data)
    for i in range(bits_data - 1, -1, -1):
        if (r >> (i + bits_total - bits_data)) & 1:
            r ^= poly << i
    return (v << (bits_total - bits_data)) | r


def _penalty(m):
    n = len(m)
    p = 0
    for rows in (m, [list(c) for c in zip(*m)]):
        for row in rows:
            run = 1
            for i in range(1, n):
                if row[i] == row[i - 1]:
                    run += 1
                else:
                    if run >= 5: p += run - 2
                    run = 1
            if run >= 5: p += run - 2
            s = "".join("1" if x else "0" for x in row)
            p += 40 * (s.count("10111010000") + s.count("00001011101"))
    for y in range(n - 1):
        for x in range(n - 1):
            if m[y][x] == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                p += 3
    dark = sum(sum(1 for x in r if x) for r in m)
    p += 10 * (abs(dark * 20 - n * n * 10) // (n * n))
    return p


def make(data):
    if isinstance(data, str):
        data = data.encode("utf-8")
    ver = None
    for v in range(1, 11):
        cap = sum(b * d for b, d in _V[v][2]) - (2 if v < 10 else 3)
        if len(data) <= cap:
            ver = v
            break
    if ver is None:
        raise ValueError("Metin QR için çok uzun")
    total, ecn, groups = _V[ver]
    ndata = sum(b * d for b, d in groups)
    bits = "0100" + format(len(data), "08b" if ver < 10 else "016b") + "".join(format(b, "08b") for b in data)
    bits += "0" * min(4, ndata * 8 - len(bits))
    bits += "0" * (-len(bits) % 8)
    cw = [int(bits[i:i + 8], 2) for i in range(0, len(bits), 8)]
    pad = [0xEC, 0x11]
    i = 0
    while len(cw) < ndata:
        cw.append(pad[i % 2]); i += 1
    blocks, pos = [], 0
    for cnt, dl in groups:
        for _ in range(cnt):
            blocks.append(cw[pos:pos + dl]); pos += dl
    ecs = [_rs(b, ecn) for b in blocks]
    final = []
    for i in range(max(len(b) for b in blocks)):
        for b in blocks:
            if i < len(b): final.append(b[i])
    for i in range(ecn):
        for e in ecs: final.append(e[i])
    stream = "".join(format(b, "08b") for b in final) + "0" * {1: 0}.get(ver, 7 if ver in (2, 3, 4, 5, 6) else 0)
    n = 17 + 4 * ver
    mod = [[False] * n for _ in range(n)]
    fn = [[False] * n for _ in range(n)]

    def setf(x, y, v):
        if 0 <= x < n and 0 <= y < n:
            mod[y][x] = v; fn[y][x] = True
    for fx, fy in ((0, 0), (n - 7, 0), (0, n - 7)):
        for dy in range(-1, 8):
            for dx in range(-1, 8):
                d = max(abs(dx - 3), abs(dy - 3))
                setf(fx + dx, fy + dy, d != 2 and d != 4)
    for i in range(n):
        if not fn[6][i]: setf(i, 6, i % 2 == 0)
        if not fn[i][6]: setf(6, i, i % 2 == 0)
    ap = _AL[ver]
    for ay in ap:
        for ax in ap:
            if (ax == 6 and ay == 6) or (ax == 6 and ay == ap[-1]) or (ax == ap[-1] and ay == 6):
                continue
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    setf(ax + dx, ay + dy, max(abs(dx), abs(dy)) != 1)
    setf(8, n - 8, True)
    for i in range(9):
        if not fn[8][i]: setf(i, 8, False)
        if not fn[i][8]: setf(8, i, False)
    for i in range(8):
        setf(n - 1 - i, 8, False); setf(8, n - 1 - i, False)
    if ver >= 7:
        vi = _bch(ver, 0x1F25, 18, 6)
        for i in range(18):
            b = (vi >> i) & 1
            setf(n - 11 + i % 3, i // 3, bool(b)); setf(i // 3, n - 11 + i % 3, bool(b))
    # veri yerleştirme
    coords = []
    x = n - 1
    up = True
    while x > 0:
        if x == 6: x -= 1
        for k in range(n):
            y = n - 1 - k if up else k
            for xx in (x, x - 1):
                if not fn[y][xx]: coords.append((xx, y))
        up = not up
        x -= 2
    base = [r[:] for r in mod]
    for i, (xx, yy) in enumerate(coords):
        base[yy][xx] = i < len(stream) and stream[i] == "1"
    best = None
    for mask in range(8):
        m = [r[:] for r in base]
        for xx, yy in coords:
            f = [(xx + yy) % 2 == 0, yy % 2 == 0, xx % 3 == 0, (xx + yy) % 3 == 0, (xx // 3 + yy // 2) % 2 == 0,
                 xx * yy % 2 + xx * yy % 3 == 0, (xx * yy % 2 + xx * yy % 3) % 2 == 0, ((xx + yy) % 2 + xx * yy % 3) % 2 == 0][mask]
            if f: m[yy][xx] = not m[yy][xx]
        fi = _bch((0 << 3) | mask, 0x537, 15, 5) ^ 0x5412  # M = 00
        # biçim bilgisi (iki kopya)
        for i in range(0, 6): m[i][8] = bool((fi >> i) & 1)
        m[7][8] = bool((fi >> 6) & 1); m[8][8] = bool((fi >> 7) & 1); m[8][7] = bool((fi >> 8) & 1)
        for i in range(9, 15): m[8][14 - i] = bool((fi >> i) & 1)
        for i in range(0, 8): m[8][n - 1 - i] = bool((fi >> i) & 1)
        for i in range(8, 15): m[n - 15 + i][8] = bool((fi >> i) & 1)
        m[n - 8][8] = True
        p = _penalty(m)
        if best is None or p < best[0]:
            best = (p, m)
    return best[1]


def svg(text, scale=4, quiet=2):
    m = make(text)
    n = len(m) + 2 * quiet
    d = []
    for y, row in enumerate(m):
        x = 0
        while x < len(row):
            if row[x]:
                s = x
                while x < len(row) and row[x]: x += 1
                d.append("M%d %dh%dv1h-%dz" % (s + quiet, y + quiet, x - s, x - s))
            else:
                x += 1
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" height="%d" shape-rendering="crispEdges">'
            '<rect width="100%%" height="100%%" fill="#fff"/><path d="%s" fill="#000"/></svg>' % (n, n, n * scale, n * scale, "".join(d)))
